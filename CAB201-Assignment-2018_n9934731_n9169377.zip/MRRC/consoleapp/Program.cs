﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MRRCManagement;

namespace ConsoleApp
{
    class Program
    {

        static void Main(string[] args)
        {
            /*
            Customer customer = new Customer(0, "Ms", "Holly", "Hutson", Gender.Female, "07/01/1990");

            
            CRM y = new CRM();
            
            y.AddCustomer(customer);
            y.RemoveCustomer(int customerID, Fleet fleet)

            // test creating fleet - check if creates new files
            Fleet x = new Fleet();
            // test adding vehicles
            Vehicle newVehicle1 = new Vehicle("123HCB", VehicleClass.Economy, "Mazda", "3", 2000, 4, TransmissionType.Automatic, FuelType.Petrol, false, false, 50, "Red");
            Vehicle newVehicle5 = new Vehicle("986KFG", VehicleClass.Family, "Suzuki", "Jimny", 2009);
            x.AddVehicle(newVehicle1);
            x.AddVehicle(newVehicle5);
            x.RemoveVehicle(newVehicle5);

            y.SaveToFile();
            x.SaveToFile();
            

            Console.WriteLine(customer);
            Console.ReadLine();
            */
        }
    }

}

