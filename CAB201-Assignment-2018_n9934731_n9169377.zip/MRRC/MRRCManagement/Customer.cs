﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/*
    The Customer class should have appropriate getters and setters for each attribute, or C# Properties
    can be used. You may want to add additional methods to enable your approach to searching.
    Gender should be an appropriately defined enum. 
 */

namespace MRRCManagement
{

    public class Customer
    {
        public enum Genders { Male, Female };

        public int CustomerID { get; private set; }
        public string Title { get; set; }
        public string FirstNames { get; set; }
        public string LastName { get; set; }
        public string DateOfBirth { get; set; }
        public Genders Gender { get; set; }


        // This constructor should construct a customer with the provided attributes.
        public Customer(int customerID, string title, string firstName, string lastName, Genders gender, string dateOfBirth)
        {
            CustomerID = customerID;
            Title = title;
            FirstNames = firstName;
            LastName = lastName;
            Gender = gender;
            DateOfBirth = dateOfBirth;
        }

        /*  
            This method should return a CSV representation of the customer that is consistent
            with the provided data files.
        */
        public string ToCSVString()
        {
            return ToString();

        }

        // This method should return a string representation of the attributes of the customer.
        public override string ToString()
        {
            return String.Join(" ", CustomerID, Title, FirstNames, LastName, Gender, DateOfBirth);
        }
    }
}
