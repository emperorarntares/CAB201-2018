﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/*  
    The vehicle class should have appropriate getters and setters for each attribute, or C# Properties can
    be used. You may want to add additional methods to enable searching.
    VehicleClass, FuelType, and TransmissionType should be appropriately defined enums.
*/

namespace MRRCManagement
{
    public class Vehicle
    {
        public enum VehicleClasses { Economy, Family, Luxury, Commercial };
        public enum TransmissionTypes { Automatic, Manual };
        public enum FuelTypes { Petrol, Diesel };

        public string VehicleRego { get; private set; }
        public string Make { get; set; }
        public string Model { get; set; }
        public int Year { get; set; }
        public VehicleClasses VehicleClass { get; set; }
        public int NumSeats { get; set; }
        public TransmissionTypes TransmissionType { get; set; }
        public FuelTypes FuelType { get; set; }
        public bool GPS { get; set; }
        public bool SunRoof { get; set; }
        public double DailyRate { get; set; }
        public string Colour { get; set; }

        // This constructor provides values for all parameters of the vehicle.
        public Vehicle(string vehicleRego, string make, string model, int year, VehicleClasses vehicleClass, int numSeats,
            TransmissionTypes transmissionType, FuelTypes fuelType, bool GPS, bool sunRoof, string colour, double dailyRate)
        {
            VehicleRego = vehicleRego;
            VehicleClass = vehicleClass;
            Make = make;
            Model = model;
            Year = year;
            NumSeats = numSeats;
            TransmissionType = transmissionType;
            FuelType = fuelType;
            this.GPS = GPS;
            SunRoof = sunRoof;
            DailyRate = dailyRate;
            Colour = colour;
        }

        /*
            This constructor provides only the mandatory parameters of the vehicle.Others are
            set based on the defaults of each class.

            Overall defaults: Unless otherwise specified by the class, vehicles default to four
            seats, automatic transmission, petrol fuel, no GPS, no sun roof, and a black colour.

            Economy vehicles: have automatic transmission only.
            Default rental cost per day is $50

            Family vehicles: can have manual or automatic transmission. Default rental cost per
            day is $80

            Luxury vehicles: has GPS and a sunroof.Default rental cost per day is $120

            Commercial vehicle: has diesel engine by default. Default rental cost per day is
            $130
        */
        public Vehicle(string vehicleRego, VehicleClasses vehicleClass, string make, string model, int year)
        {
            VehicleRego = vehicleRego;

            NumSeats = 4;
            TransmissionType = TransmissionTypes.Automatic;
            FuelType = FuelTypes.Petrol;
            GPS = false;
            SunRoof = false;
            Colour = "Black";
            Make = make;
            Model = model;
            Year = year;

            if (vehicleClass == VehicleClasses.Economy)
            {
                TransmissionType = TransmissionTypes.Automatic;
                DailyRate = 50.00;
                VehicleClass = vehicleClass;
            }

            else if (vehicleClass == VehicleClasses.Family)
            {
                DailyRate = 80.00;
                VehicleClass = vehicleClass;
            }

            else if (vehicleClass == VehicleClasses.Luxury)
            {
                GPS = true;
                SunRoof = true;
                DailyRate = 120.00;
                VehicleClass = vehicleClass;
            }

            else if (vehicleClass == VehicleClasses.Commercial)
            {
                FuelType = FuelTypes.Diesel;
                DailyRate = 130.00;
                VehicleClass = vehicleClass;
            }


        }

        /*
            This method should return a CSV representation of the vehicle that is consistent
            with the provided data files.
        */
        public string ToCSVString()
        {
            // return String.Join(VehicleRego, VehicleClass, Make, Model , Year.ToString(), NumSeats.ToString(), TransmissionType, FuelType, GPS, SunRoof, DailyRate.ToString(), Colour);
            return ToString();
        }

        // This method should return a string representation of the attributes of the vehicle.
        public override string ToString()
        {
            //return VehicleRego + VehicleClass + Make + Model + Year.ToString() + NumSeats.ToString() + TransmissionType + FuelType + GPS + SunRoof + DailyRate.ToString() + Colour;
            return String.Join(" ", VehicleRego, VehicleClass, Make, Model, Year.ToString(), NumSeats.ToString(), TransmissionType, FuelType, GPS, SunRoof, DailyRate.ToString(), Colour);

        }

        /*
            This method should return a list of strings which represent each attribute.Values
            should be made to be unique, e.g.numSeats should not be written as ‘4’ but as ‘4-
            Seater’, sunroof should not be written as ‘True’ but as ‘sunroof’ or with no string
            added if there is no sunroof. Vehicle rego, class, make, model, year, transmission
            type, fuel type, daily rate, and colour can all be assumed to not overlap(i.e. if
            the make ‘Mazda’ exists, ‘Mazda’ will not exist in other attributes e.g.there is
            no model named ‘Mazda’. Similarly, if the colour ‘red’ exists, there is no ‘red’
            make.You do not need to maintain this restriction, only assume it is true.)
        */

        public List<string> GetAttributeList()
        {
            List<string> attributeList = new List<string>();

            attributeList.Add(VehicleRego);
            attributeList.Add(VehicleClass.ToString());
            attributeList.Add(Make);
            attributeList.Add(Model);
            attributeList.Add(Year.ToString());
            attributeList.Add(TransmissionType.ToString());
            attributeList.Add(FuelType.ToString());
            attributeList.Add(DailyRate.ToString());
            attributeList.Add(Colour);
            attributeList.Add(GPS + "GPS");
            attributeList.Add(SunRoof + "sunroof");
            attributeList.Add(NumSeats + "-Seater");

            return attributeList;
        }
    }
}
