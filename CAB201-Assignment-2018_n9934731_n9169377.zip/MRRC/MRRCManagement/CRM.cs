﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

/*
    A CRM class manages the collection of customers. The CRM class should load the customers from file
    on start-up. This class should be based on a list of Customer objects. It should support operations on
    the Customer (e.g. add/modify/delete).
    The program must make sure that data entry makes sure that customerID is unique (no
    duplicates allowed). You can assume that data on disk (i.e. read from files) is
    always valid. You may want to implement this by automatically generating a unique
    customerID (for example, you might want to keep track of the current highest customer
    ID).
 */

namespace MRRCManagement
{
    public class CRM
    {
        // location of the customer.csv
        private string crmFile = @"..\..\..\Data\customer.csv";

        // list to handle customers
        private List<Customer> customers = new List<Customer>();

        /*
            If there is no CRM file at the specified location, this constructor constructors an
            empty CRM with no customers. Otherwise it loads the customers from file.
         */
        public CRM()
        {
            // if the customer.csv doesn't exist, create a new list
            if (!File.Exists(crmFile))
            {
                customers = new List<Customer>();
            }
            // otherwise we load the file
            else
            {
                LoadFromFile();
            }
        }

        /*
            This method adds the provided customer to the customer list if the customer ID
            doesn’t already exist in the CRM. It returns true if the addition was successful
            (the customer ID wasn’t already in the CRM) and false otherwise (the customer ID
            was already in the CRM).
         */
        public bool AddCustomer(Customer customer)
        {
            // if the customer is not in the list we add them
            if (!customers.Contains(customer))
            {
                customers.Add(customer);
                return true;
            }
            // else we do nothing
            return false;
        }

        /*
           This method removes the customer from the CRM if they are not currently renting a
           vehicle. It returns true if the removal was successful, otherwise it returns false
        */
        public bool RemoveCustomer(Customer customer, Fleet fleet)
        {
            // if customer isnt renting vehicle remove from list
            if (!customer.Equals(fleet))
            {
                customers.Remove(customer);
                return true;
            }
            // else we do nothing
            return false;
        }

        public void RemoveCustomer(Customer customer)
        {
            customers.Remove(customer);
        }


        /*
            This method removes the customer from the CRM if they are not currently renting a
            vehicle. It returns true if the removal was successful, otherwise it returns false. 
        */

        public bool RemoveCustomer(int customerID, Fleet fleet)
        {
            if (!customerID.Equals(fleet))
            {
                return true;
            }
            return false;
        }

        /*
             This method returns the list of current customers.
        */
        public List<Customer> GetCustomers()
        {
            return customers;
        }

        /*
            This method saves the current state of the CRM to file.
        */
        public void SaveToFile()
        {
            StreamWriter fileWriter = new StreamWriter(crmFile);

            //Write the header
            fileWriter.WriteLine("customerID,Title,FirstName,LastName,Gender,DOB");

            foreach (Customer details in customers)
            {
                fileWriter.WriteLine("{0},{1},{2},{3},{4},{5}", details.CustomerID.ToString(), details.Title, details.FirstNames, details.LastName, details.Gender.ToString(), details.DateOfBirth);
            }

            fileWriter.Close();
        }


        /*This method loads the state of the CRM from file.*/
        public void LoadFromFile()
        {
            StreamReader fileReader = new StreamReader(crmFile);

            //read and ignore the header line
            fileReader.ReadLine();

            string line;
            while ((line = fileReader.ReadLine()) != null)
            {
                string[] parts = line.Split(',');
                Customer newCustomer = new Customer(int.Parse(parts[0]), parts[1], parts[2], parts[3],
                                                    (Customer.Genders)Enum.Parse(typeof(Customer.Genders), parts[4]), parts[5]);
                customers.Add(newCustomer);
            }
            fileReader.Close();
        }

        // Retrieve list of customers for data grid
        public Customer GetCustomer(int CID)
        {
            foreach (Customer customer in customers)
            {
                if (customer.CustomerID == CID)
                {
                    return customer;
                }
            }
            return null;
        }
    }
}
