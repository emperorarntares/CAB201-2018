﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

/*
    A Fleet class manages the rental of vehicles. The fleet class should load the vehicle fleet from file on
    start-up. This class should be based on list of Vehicle objects. It should support operations on the
    fleet, such as adding, modifying and deleting vehicles. It should also handle the renting and returning
    of vehicles.

    You may adjust some private variables or methods if they better suit your approach. For example, you
    may prefer to take a different approach to the Dictionary with the vehicle rego and customerID for
    maintaining which cars are being rented.
    The methods needed to implement the search functionality have not been specified here. It is up to
    you to come up with your own approach.

    The program must make sure that data entry makes sure that VehicleRego is unique
    (no duplicates allowed) and that it only has 6 alphanumeric characters (i.e. in [AZ,
    0-9]) when entered from the keyboard. You can assume that data on disk (i.e.
    read from files) is always valid.
 */

namespace MRRCManagement
{
    public class Fleet
    {

        private List<Vehicle> vehicles = new List<Vehicle>();
        private Dictionary<string, int> rentals = new Dictionary<string, int>();
        private string fleetFile = @"..\..\..\Data\fleet.csv";
        private string rentalFile = @"..\..\..\Data\rentals.csv";

        /*
            If there is no fleet file at the specified location, this constructor constructors
            an empty fleet and empty rentals.Otherwise it loads the fleet and rentals from the
            appropriate files.
        */
        public Fleet()
        {
            if (!File.Exists(fleetFile))
            {
                vehicles = new List<Vehicle>(vehicles);
                rentals = new Dictionary<string, int>();
            }
            else
            {
                LoadFromFile();
            }
        }

        /*
             This method adds the provided vehicle to the fleet assuming the vehicle registration
             does not already exist. It returns true if the add was successful (the vehicleRego
             wasn’t already in the fleet), and false otherwise (a car with that rego was already
             in the fleet).
        */
        public bool AddVehicle(Vehicle vehicle)
        {
            if (!vehicles.Contains(vehicle))
            {
                vehicles.Add(vehicle);
                return true;
            }
            return false;
        }

        /*
           This method removes the provided vehicle from the fleet if it is not currently
           rented. It returns true if the removal was successful and false otherwise.
        */
        public bool RemoveVehicle(Vehicle vehicle)
        {
            if (vehicles.Contains(vehicle))
            {
                vehicles.Remove(vehicle);
                return true;
            }
            return false;
        }

        /*  
              This method removes the vehicle with the provided rego from the fleet if it is not
              currently rented.It returns true if the removal was successful and false otherwise.
        */
        public bool RemoveVehicle(string vehicleRego)
        {
            if (!rentals.ContainsKey(vehicleRego))
            {
                rentals.Remove(vehicleRego);
                return true;
            }
            return false;
        }


        // This method returns the fleet.
        public List<Vehicle> GetFleet()
        {
            return vehicles;
        }

        // This method saves the current state of the fleet to file.
        public void SaveToFile()
        {
            StreamWriter fileWriter = new StreamWriter(fleetFile);

            //Write the header
            fileWriter.WriteLine("Rego, Make, Model, Year, VehicleClass, NumSeats, Transmission, Fuel, GPS, SunRoof, Colour, DailyRate");

            foreach (Vehicle vehicle in vehicles)
            {
                fileWriter.WriteLine("{0},{1},{2},{3},{4},{5},{6},{7},{8},{9},{10},{11}", vehicle.VehicleRego,
                vehicle.Make, vehicle.Model, vehicle.Year.ToString(), vehicle.VehicleClass,vehicle.NumSeats,
                vehicle.TransmissionType, vehicle.FuelType, vehicle.GPS, vehicle.SunRoof, vehicle.Colour,
                vehicle.DailyRate);
            }

            fileWriter.Close();
        }

        // This method loads the state of the fleet from file.

        public void LoadFromFile()
        {
            StreamReader fileReader = new StreamReader(fleetFile);

            //read and ignore the header line
            fileReader.ReadLine();

            string line;
            while ((line = fileReader.ReadLine()) != null)
            {
                string[] parts = line.Split(',');
                Vehicle newVehicle = new Vehicle(parts[0], parts[1], parts[2], int.Parse(parts[3]), 
                (Vehicle.VehicleClasses)Enum.Parse(typeof(Vehicle.VehicleClasses), parts[4]), int.Parse(parts[5]), 
                (Vehicle.TransmissionTypes)Enum.Parse(typeof(Vehicle.TransmissionTypes), parts[6]), 
                (Vehicle.FuelTypes)Enum.Parse(typeof(Vehicle.FuelTypes), parts[7]), bool.Parse(parts[8]), bool.Parse(parts[9]), 
                parts[10], double.Parse(parts[11]));

                vehicles.Add(newVehicle);
            }
            fileReader.Close();
        }

        // Retrieves the fleet and inserts to data grid
        public Vehicle GetFleet(string rego)
        {
            foreach (Vehicle vehicle in vehicles)
            {
                if (vehicle.VehicleRego == rego)
                {
                    return vehicle;
                }
            }
            return null;
        }

        // Search query for rental vehicles
        public List<Vehicle> RetrieveVehicles(bool isNotRenting)
        {
            List<Vehicle> requestedVehicles = new List<Vehicle>();

            foreach (Vehicle cars in vehicles)
            {
                if (rentals.ContainsKey(cars.VehicleRego) == isNotRenting)
                {
                    requestedVehicles.Add(cars);
                }
            }

            return requestedVehicles;
        }


        public List<Vehicle> RetrieveVehicles(string searchQuery)
        {
            List<Vehicle> requestedVehicles = new List<Vehicle>();

            String[] queryParts = searchQuery.Split(' ');

            // for each query keyword
            for (int i = 0; i < queryParts.Length; i = i + 2)
            {
                //for the first keyword
                if (i == 0)
                {
                    foreach (Vehicle carNotRenting in RetrieveVehicles(false))
                    {
                        if (carNotRenting.GetAttributeList().Contains(queryParts[i]))
                        {
                            requestedVehicles.Add(carNotRenting);
                        }
                    }
                }
                else if (queryParts[i - 1] == "OR")
                {
                    List<Vehicle> tempCars = new List<Vehicle>();

                    foreach (Vehicle carNotRenting in RetrieveVehicles(false))
                    {
                        if (carNotRenting.GetAttributeList().Contains(queryParts[i]))
                        {
                            tempCars.Add(carNotRenting);
                        }
                    }

                    requestedVehicles = requestedVehicles.Union(tempCars).ToList();
                }
                else if (queryParts[i - 1] == "AND")
                {
                    List<Vehicle> tempCars = new List<Vehicle>();

                    foreach (Vehicle carNotRenting in RetrieveVehicles(false))
                    {
                        if (carNotRenting.GetAttributeList().Contains(queryParts[i]))
                        {
                            tempCars.Add(carNotRenting);
                        }
                    }

                    requestedVehicles = requestedVehicles.Intersect(tempCars).ToList();
                }
            }
            return requestedVehicles;
        }
    }
}
