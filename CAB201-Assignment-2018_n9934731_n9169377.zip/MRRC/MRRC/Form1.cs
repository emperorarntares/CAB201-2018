﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MRRCManagement;
using System.Text.RegularExpressions;

namespace MRRC
{
    public partial class Form1 : Form
    {
        // Setup classes and lists
        CRM crm = new CRM();
        Fleet fleet = new Fleet();
        private Vehicle selectedVehicle;
        private Customer selectedCustomer;

        // Initialise data grid with columns
        private string[] fleetColumn = new string[]
        {
          "Rego","Make", "Model", "Year", "Vehicle Class",
          "Seats","Transmission", "Fuel", "GPS", "Sunroof",
          "Daily Rate", "Colour"
        };

        private string[] customerColumn = new string[]
        {
            "Customers ID", "Title", "First Name",
            "Last Name", "Gender", "DOB"
        };

        private string[] reportColumn = new string[]
        {
            "Vehicle Rego", "Customer ID", "Daily rate"
        };

        private string[] searchColumn = new string[]
        {
            "Rego","Make", "Model", "Year", "VechClass",
            "NumSeats","Transmission", "Fuel", "GPS",
            "Sunroof", "Daily Rate", "Colour"
        };

        // Setup and load GUI functions
        public Form1()
        {
            InitializeComponent();
            SetupFleetDataGridViewColumns();
            SetupCustomerDataGridViewColumns();
            SetupReportDataGridViewColumns();
            SetupSearchtDataGridViewColumns();
            LoadCustomersToGrid();
            LoadFleetToGrid();
        }

        // Setup grid views
        private void SetupFleetDataGridViewColumns()
        {
            fleetDataGridView.ColumnCount = fleetColumn.Length;
            for (int i = 0; i < fleetColumn.Length; i++)
            {
                fleetDataGridView.Columns[i].Name = fleetColumn[i];
            }
        }

        private void SetupCustomerDataGridViewColumns()
        {
            customersDataGridView.ColumnCount = customerColumn.Length;
            for (int i = 0; i < customerColumn.Length; i++)
            {
                customersDataGridView.Columns[i].Name = customerColumn[i];
            }
        }

        private void SetupReportDataGridViewColumns()
        {
            reportDataGridView.ColumnCount = reportColumn.Length;
            for (int i = 0; i < reportColumn.Length; i++)
            {
                reportDataGridView.Columns[i].Name = reportColumn[i];
            }
        }

        private void SetupSearchtDataGridViewColumns()
        {
            searchDataGridView.ColumnCount = searchColumn.Length;
            for (int i = 0; i < searchColumn.Length; i++)
            {
                searchDataGridView.Columns[i].Name = searchColumn[i];
            }
        }

        // Load class lists to data grid
        public void LoadCustomersToGrid()
        {
            customersDataGridView.Rows.Clear();
            foreach (Customer customer in crm.GetCustomers())
            {

                customersDataGridView.Rows.Add(new string[]
                {
                  customer.CustomerID.ToString(), customer.Title, customer.FirstNames,
                  customer.LastName, customer.Gender.ToString(), customer.DateOfBirth
                });
            }
        }

        public void LoadFleetToGrid()
        {
            fleetDataGridView.Rows.Clear();
            foreach (Vehicle vehicle in fleet.GetFleet())
            {
                fleetDataGridView.Rows.Add(new string[]
                {
                  vehicle.VehicleRego,  vehicle.Make,  vehicle.Model, vehicle.Year.ToString(), vehicle.VehicleClass.ToString(),
                  vehicle.NumSeats.ToString(), vehicle.TransmissionType.ToString(), vehicle.FuelType.ToString(), vehicle.GPS.ToString(),
                  vehicle.SunRoof.ToString(), vehicle.DailyRate.ToString(), vehicle.Colour
                });
            }
        }

        // Enable the ability to select row ID for fleet & CRM
        private void fleetDataGridView_SelectionChanged(object sender, EventArgs e)
        {
            int rowsCount = fleetDataGridView.SelectedRows.Count;

            if (rowsCount == 0 || rowsCount > 1)
            {
                selectedVehicle = null;
            }
            else
            {
                txtRego.Text = fleetDataGridView.SelectedRows[0].Cells[0].Value.ToString();
                txtMake.Text = (fleetDataGridView.SelectedRows[0].Cells[1].Value.ToString());
                txtModel.Text = (fleetDataGridView.SelectedRows[0].Cells[2].Value.ToString());
                txtYear.Text = (fleetDataGridView.SelectedRows[0].Cells[3].Value.ToString());
                txtClass.Text = (fleetDataGridView.SelectedRows[0].Cells[4].Value.ToString());
                numericUpDownSeats.Text = (fleetDataGridView.SelectedRows[0].Cells[5].Value.ToString());
                txtTransmission.Text = (fleetDataGridView.SelectedRows[0].Cells[6].Value.ToString());
                txtFuel.Text = (fleetDataGridView.SelectedRows[0].Cells[7].Value.ToString());

                if (fleetDataGridView.SelectedRows[0].Cells[8].Value.ToString() == "True")
                {
                    checkBoxGPS.Checked = true;
                }
                else
                {
                    checkBoxGPS.Checked = false;
                }


                if (fleetDataGridView.SelectedRows[0].Cells[9].Value.ToString() == "True")
                {
                    checkBoxSunRoof.Checked = true;
                }
                else
                {
                    checkBoxSunRoof.Checked = false;
                }

                numericUpDownDailyRate.Text = (fleetDataGridView.SelectedRows[0].Cells[10].Value.ToString());
                txtColour.Text = (fleetDataGridView.SelectedRows[0].Cells[11].Value.ToString());

                string selectedrego = fleetDataGridView.SelectedRows[0].Cells[0].Value.ToString();
                selectedVehicle = fleet.GetFleet(selectedrego);
            }

        }

        private void customersDataGridView_SelectionChanged(object sender, EventArgs e)
        {

            int rowsCount = customersDataGridView.SelectedRows.Count;

            if (rowsCount == 0 || rowsCount > 1)
            {
                selectedCustomer = null;
            }
            else
            {
                txtCustID.Text = (customersDataGridView.SelectedRows[0].Cells[0].Value.ToString());
                txtTitle.Text = (customersDataGridView.SelectedRows[0].Cells[1].Value.ToString());
                txtFirstName.Text = (customersDataGridView.SelectedRows[0].Cells[2].Value.ToString());
                txtLastName.Text = (customersDataGridView.SelectedRows[0].Cells[3].Value.ToString());
                txtDOB.Text = (customersDataGridView.SelectedRows[0].Cells[5].Value.ToString());
                txtGender.Text = (customersDataGridView.SelectedRows[0].Cells[4].Value.ToString());

                int selectedId = int.Parse(customersDataGridView.SelectedRows[0].Cells[0].Value.ToString());
                selectedCustomer = crm.GetCustomer(selectedId);
            }
        }

        // Modify mode enabled
        private void modifyFleet_Click(object sender, EventArgs e)
        {
            fleetGroupBox.Enabled = false;
            modifyVehicleGroupBox.Enabled = true;
            modifyVehicleGroupBox.Visible = true;
            modifyVehicleGroupBox.Text = "Modify Vehicle";

            int rowCount = fleetDataGridView.SelectedRows.Count;
            if (rowCount == 0 || rowCount > 1)
            {
                selectedVehicle = null;
            }
            else
            {
                txtRego.Text = (fleetDataGridView.SelectedRows[0].Cells[0].Value.ToString());
                txtMake.Text = (fleetDataGridView.SelectedRows[0].Cells[1].Value.ToString());
                txtModel.Text = (fleetDataGridView.SelectedRows[0].Cells[2].Value.ToString());
                txtYear.Text = (fleetDataGridView.SelectedRows[0].Cells[3].Value.ToString());
                txtClass.Text = (fleetDataGridView.SelectedRows[0].Cells[4].Value.ToString());
                numericUpDownSeats.Text = (fleetDataGridView.SelectedRows[0].Cells[5].Value.ToString());
                txtTransmission.Text = (fleetDataGridView.SelectedRows[0].Cells[6].Value.ToString());
                txtFuel.Text = (fleetDataGridView.SelectedRows[0].Cells[7].Value.ToString());
                numericUpDownDailyRate.Text = (fleetDataGridView.SelectedRows[0].Cells[10].Value.ToString());
                txtColour.Text = (fleetDataGridView.SelectedRows[0].Cells[11].Value.ToString());

                if (fleetDataGridView.SelectedRows[0].Cells[8].Value.ToString() == "True")
                {
                    checkBoxGPS.Checked = true;
                }
                else
                {
                    checkBoxGPS.Checked = false;
                }


                if (fleetDataGridView.SelectedRows[0].Cells[9].Value.ToString() == "True")
                {
                    checkBoxSunRoof.Checked = true;
                }
                else
                {
                    checkBoxSunRoof.Checked = false;
                }

                txtRego.Enabled = false;
            }
        }

        private void modifyCustomer_Click(object sender, EventArgs e)
        {
            modifyCRMgroupBox.Enabled = false;
            modifyCustomerGroupBox.Enabled = true;
            modifyCustomerGroupBox.Visible = true;
            modifyCustomerGroupBox.Text = "Modify Customer";

            int rowsCount = customersDataGridView.SelectedRows.Count;

            if (rowsCount == 0 || rowsCount > 1)
            {
                selectedCustomer = null;
            }
            else
            {
                int selectedId = int.Parse(customersDataGridView.SelectedRows[0].Cells[0].Value.ToString());
                selectedCustomer = crm.GetCustomer(selectedId);

                txtCustID.Text = (customersDataGridView.SelectedRows[0].Cells[0].Value.ToString());
                txtTitle.Text = (customersDataGridView.SelectedRows[0].Cells[1].Value.ToString());
                txtFirstName.Text = (customersDataGridView.SelectedRows[0].Cells[2].Value.ToString());
                txtLastName.Text = (customersDataGridView.SelectedRows[0].Cells[3].Value.ToString());
                txtDOB.Text = (customersDataGridView.SelectedRows[0].Cells[5].Value.ToString());
                txtGender.Text = (customersDataGridView.SelectedRows[0].Cells[4].Value.ToString());

            }

            txtCustID.Enabled = false;
        }


        // Add mode enabled
        private void addFleet_Click(object sender, EventArgs e)
        {
            fleetGroupBox.Enabled = false;
            modifyVehicleGroupBox.Enabled = true;
            modifyVehicleGroupBox.Visible = true;
            modifyVehicleGroupBox.Text = "Add Vehicle";
            checkBoxSunRoof.Checked = false;
            checkBoxGPS.Checked = false;
            txtRego.Enabled = true;
            txtRego.Text = "";
            txtMake.Text = "";
            txtModel.Text = "";
            txtClass.Text = "";
            txtYear.Text = "";
            txtTransmission.Text = "";
            txtFuel.Text = "";
            numericUpDownSeats.Text = "";
            txtColour.Text = "";
            numericUpDownDailyRate.Text = "";


        }

        private void addCustomer_Click(object sender, EventArgs e)
        {
            modifyCRMgroupBox.Enabled = false;
            modifyCustomerGroupBox.Enabled = true;
            modifyCustomerGroupBox.Visible = true;
            modifyCustomerGroupBox.Text = "Add Customer";
            txtCustID.Text = "";
            txtTitle.Text = "";
            txtFirstName.Text = "";
            txtLastName.Text = "";
            txtDOB.Text = "";
            txtGender.Text = "";

            txtCustID.Enabled = true;

        }

        // Remove an item from the grid
        private void removeFleet_Click(object sender, EventArgs e)
        {
            DialogResult dialogResult = MessageBox.Show(String.Format("Do you really want to remove Vehicle {0}?",
            selectedVehicle.VehicleRego), "Remove Vehicle confirmation", MessageBoxButtons.YesNo);

            if (dialogResult == DialogResult.Yes)
            {
                fleet.RemoveVehicle(selectedVehicle);
                fleet.SaveToFile();
                LoadFleetToGrid();
            }
        }

        private void removeCustomer_Click(object sender, EventArgs e)
        {
            DialogResult dialogResult = MessageBox.Show(String.Format("Do you really want to remove customer {0}?",
            selectedCustomer.CustomerID), "Remove customer confirmation", MessageBoxButtons.YesNo);

            if (dialogResult == DialogResult.Yes)
            {
                crm.RemoveCustomer(selectedCustomer);
                crm.SaveToFile();
                LoadCustomersToGrid();
            }
        }

        // Closes the fleet groupbox, clearing every input
        private void closeButton_Click(object sender, EventArgs e)
        {
            fleetGroupBox.Enabled = true;
            modifyVehicleGroupBox.Enabled = false;
            modifyVehicleGroupBox.Visible = false;
            txtRego.Text = "";
            txtMake.Text = "";
            txtModel.Text = "";
            txtClass.Text = "";
            txtYear.Text = "";
            txtTransmission.Text = "";
            txtFuel.Text = "";
            numericUpDownSeats.Text = "";
            checkBoxSunRoof.Text = "";
            checkBoxGPS.Text = "";
            txtColour.Text = "";
            numericUpDownDailyRate.Text = "";
        }

        private void closeButton2_Click(object sender, EventArgs e)
        {
            modifyCRMgroupBox.Enabled = true;
            modifyCustomerGroupBox.Enabled = false;
            modifyCustomerGroupBox.Visible = false;
            txtCustID.Text = "";
            txtTitle.Text = "";
            txtFirstName.Text = "";
            txtLastName.Text = "";
            txtDOB.Text = "";
            txtGender.Text = "";
        }

        // Button submission conditions

        // Submit fleet
        public bool invalidRego()
        {
            foreach (DataGridViewRow row in fleetDataGridView.Rows)
            {
                if (row.Cells[0].Value.ToString().Equals(txtRego.Text))
                {
                    return true;
                }
            }
            return false;
        }
        private void submitFleetButton_Click(object sender, EventArgs e)
        {
            String regoValidate = @"^[0-9]{3}[A-Z]{3}$";
            fleetGroupBox.Enabled = true;

            // Modify fleet conditions
            if (modifyVehicleGroupBox.Text == "Modify Vehicle")
            {
                fleetDataGridView.SelectedRows[0].Cells[0].Value = txtRego.Text;
                fleetDataGridView.SelectedRows[0].Cells[1].Value = txtMake.Text;
                fleetDataGridView.SelectedRows[0].Cells[2].Value = txtModel.Text;
                fleetDataGridView.SelectedRows[0].Cells[3].Value = txtYear.Text;
                fleetDataGridView.SelectedRows[0].Cells[4].Value = txtClass.Text;
                fleetDataGridView.SelectedRows[0].Cells[5].Value = numericUpDownSeats.Text;
                fleetDataGridView.SelectedRows[0].Cells[6].Value = txtTransmission.Text;
                fleetDataGridView.SelectedRows[0].Cells[7].Value = txtFuel.Text;

                // Insert tick box statements into data grid
                if (checkBoxGPS.Checked == true)
                {
                    fleetDataGridView.SelectedRows[0].Cells[8].Value = "True";
                }
                else if (checkBoxGPS.Checked == false)
                {
                    fleetDataGridView.SelectedRows[0].Cells[8].Value = "False";
                }
                if (checkBoxSunRoof.Checked == true)
                {
                    fleetDataGridView.SelectedRows[0].Cells[9].Value = "True";
                }
                else if (checkBoxSunRoof.Checked == false)
                {
                    fleetDataGridView.SelectedRows[0].Cells[9].Value = "False";
                }

                fleetDataGridView.SelectedRows[0].Cells[10].Value = numericUpDownDailyRate.Text;
                fleetDataGridView.SelectedRows[0].Cells[11].Value = txtColour.Text;

                // If inputs are not provided, display error
                if (txtRego.Text == "" || txtMake.Text == "" || txtModel.Text == "" || txtYear.Text == "" ||
                    txtClass.Text == "" || numericUpDownSeats.Text == "" && txtTransmission.Text == "" ||
                    txtFuel.Text == "" || numericUpDownDailyRate.Text == "" && txtColour.Text == "")
                {
                    MessageBox.Show("Inputs are not completed.", "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                // Else, add to list
                else
                {
                    string rego = txtRego.Text;
                    string make = txtMake.Text;
                    string model = txtModel.Text;
                    int year = int.Parse(txtYear.Text);
                    string vehClass = txtClass.Text;
                    int seats = int.Parse(numericUpDownSeats.Text);
                    string transmission = txtTransmission.Text;
                    string fuel = txtFuel.Text;
                    double dailyRate = double.Parse(numericUpDownDailyRate.Text);
                    string colour = txtColour.Text;
                    bool sunroof = checkBoxSunRoof.Checked;
                    bool gps = checkBoxGPS.Checked;

                    Vehicle newVehicle = new Vehicle(rego, make, model, year,
                    (Vehicle.VehicleClasses)Enum.Parse(typeof(Vehicle.VehicleClasses), vehClass), seats,
                    (Vehicle.TransmissionTypes)Enum.Parse(typeof(Vehicle.TransmissionTypes), transmission),
                    (Vehicle.FuelTypes)Enum.Parse(typeof(Vehicle.FuelTypes), fuel), sunroof, gps, colour, dailyRate);

                    fleet.RemoveVehicle(selectedVehicle);
                    fleet.AddVehicle(newVehicle);

                    txtRego.Text = "";
                    txtMake.Text = "";
                    txtModel.Text = "";
                    txtClass.Text = "";
                    txtYear.Text = "";
                    txtTransmission.Text = "";
                    txtFuel.Text = "";
                    numericUpDownSeats.Text = "";
                    checkBoxSunRoof.Text = "";
                    checkBoxGPS.Text = "";
                    txtColour.Text = "";
                    numericUpDownDailyRate.Text = "";

                    MessageBox.Show("A vehicle has been modified in the fleet.", "Modify vehicle successful",
                    MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                    fleet.SaveToFile();

                    LoadFleetToGrid();
                }
            }
            // Add vehicle conditions
            else if (modifyVehicleGroupBox.Text == "Add Vehicle")
            {
                // If inputs are not provided, display error
                if (txtRego.Text == "" || txtMake.Text == "" || txtModel.Text == "" || txtYear.Text == "" ||
                    txtClass.Text == "")
                {
                    MessageBox.Show("Inputs are not completed.", "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else if (!Regex.IsMatch(txtRego.Text, regoValidate))
                {
                    MessageBox.Show("Vehicle rego must have 3 numbers, follow by 3 uppercase letters.", "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else if (invalidRego() == true)
                {
                    MessageBox.Show("Vehicle rego is already registered.", "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

                else
                {
                    if (numericUpDownSeats.Text == "" && txtTransmission.Text == "" &&
                    txtFuel.Text == "" && numericUpDownDailyRate.Text == "" && txtColour.Text == "")
                    {
                        string regos = txtRego.Text;
                        string makes = txtMake.Text;
                        string models = txtModel.Text;
                        int years = int.Parse(txtYear.Text);
                        string vehClasses = txtClass.Text;
                        Vehicle newVeh = new Vehicle(regos, (Vehicle.VehicleClasses)Enum.Parse(typeof(Vehicle.VehicleClasses), vehClasses)
                            , makes, models, years);
                        fleet.AddVehicle(newVeh);

                        MessageBox.Show("A vehicle has been added to the fleet.", "Add vehicle successful",
                        MessageBoxButtons.OK, MessageBoxIcon.Asterisk);

                        fleet.SaveToFile();

                        LoadFleetToGrid();

                        txtRego.Text = "";
                        txtMake.Text = "";
                        txtModel.Text = "";
                        txtClass.Text = "";
                        txtYear.Text = "";
                        txtTransmission.Text = "";
                        txtFuel.Text = "";
                        numericUpDownSeats.Text = "";
                        checkBoxSunRoof.Text = "";
                        checkBoxGPS.Text = "";
                        txtColour.Text = "";
                        numericUpDownDailyRate.Text = "";
                    }
                    else
                    {
                        string rego = txtRego.Text;
                        string make = txtMake.Text;
                        string model = txtModel.Text;
                        int year = int.Parse(txtYear.Text);
                        string vehClass = txtClass.Text;
                        int seats = int.Parse(numericUpDownSeats.Text);
                        string transmission = txtTransmission.Text;
                        string fuel = txtFuel.Text;
                        double dailyRate = double.Parse(numericUpDownDailyRate.Text);
                        string colour = txtColour.Text;
                        bool sunroof = checkBoxSunRoof.Checked;
                        bool gps = checkBoxGPS.Checked;

                        Vehicle newVehicle = new Vehicle(rego, make, model, year,
                       (Vehicle.VehicleClasses)Enum.Parse(typeof(Vehicle.VehicleClasses), vehClass), seats,
                       (Vehicle.TransmissionTypes)Enum.Parse(typeof(Vehicle.TransmissionTypes), transmission),
                       (Vehicle.FuelTypes)Enum.Parse(typeof(Vehicle.FuelTypes), fuel), sunroof, gps, colour, dailyRate);

                        fleet.AddVehicle(newVehicle);

                        MessageBox.Show("A vehicle has been added to the fleet.", "Add vehicle successful",
                        MessageBoxButtons.OK, MessageBoxIcon.Asterisk);

                        fleet.SaveToFile();

                        LoadFleetToGrid();

                        txtRego.Text = "";
                        txtMake.Text = "";
                        txtModel.Text = "";
                        txtClass.Text = "";
                        txtYear.Text = "";
                        txtTransmission.Text = "";
                        txtFuel.Text = "";
                        numericUpDownSeats.Text = "";
                        checkBoxSunRoof.Text = "";
                        checkBoxGPS.Text = "";
                        txtColour.Text = "";
                        numericUpDownDailyRate.Text = "";
                    }
                }
            }
        }

        // Submit CRM
        public bool invalidCustID()
        {
            foreach (DataGridViewRow row in customersDataGridView.Rows)
            {
                if (row.Cells[0].Value.ToString().Equals(txtCustID.Text))
                {
                    return true;
                }
            }
            return false;
        }

        private void submitCustomerButton_Click(object sender, EventArgs e)
        {
            modifyCRMgroupBox.Enabled = true;
            String dobValidate = @"^(0[1-9]|[12][0-9]|3[01])[- /.](0[1-9]|1[012])[- /.](19|20)\d\d$";
            if (modifyCustomerGroupBox.Text == "Modify Customer")
            {
                customersDataGridView.SelectedRows[0].Cells[0].Value = txtCustID.Text;
                customersDataGridView.SelectedRows[0].Cells[1].Value = txtTitle.Text;
                customersDataGridView.SelectedRows[0].Cells[2].Value = txtFirstName.Text;
                customersDataGridView.SelectedRows[0].Cells[3].Value = txtLastName.Text;
                customersDataGridView.SelectedRows[0].Cells[4].Value = txtGender.Text;
                customersDataGridView.SelectedRows[0].Cells[5].Value = txtDOB.Text;

                if (txtCustID.Text == "" || txtTitle.Text == "" || txtFirstName.Text == "" ||
                    txtLastName.Text == "" || txtGender.Text == "" || txtDOB.Text == "")
                {
                    MessageBox.Show("Inputs are not completed.", "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else if (!Regex.IsMatch(txtDOB.Text, dobValidate))
                {
                    MessageBox.Show("DOB input invalid. Use DD/MM/YYYY", "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    int custID = int.Parse(txtCustID.Text);
                    string tit = txtTitle.Text;
                    string firName = txtFirstName.Text;
                    string lasName = txtLastName.Text;
                    string gen = txtGender.Text;
                    string dob = txtDOB.Text;

                    Customer newCustomer = new Customer(custID, tit, firName, lasName,
                   (Customer.Genders)Enum.Parse(typeof(Customer.Genders), gen), dob);

                    crm.RemoveCustomer(selectedCustomer);
                    crm.AddCustomer(newCustomer);

                    txtCustID.Text = "";
                    txtTitle.Text = "";
                    txtFirstName.Text = "";
                    txtLastName.Text = "";
                    txtDOB.Text = "";
                    txtGender.Text = "";

                    MessageBox.Show(String.Format("Customer {0} has been modified",
                    selectedCustomer.CustomerID), "Modify customer successful.",
                    MessageBoxButtons.OK, MessageBoxIcon.Asterisk);

                    crm.SaveToFile();

                    LoadCustomersToGrid();
                }

            }
            else if (modifyCustomerGroupBox.Text == "Add Customer")
            {

                if (txtCustID.Text == "" || txtTitle.Text == "" || txtFirstName.Text == "" ||
                    txtLastName.Text == "" || txtGender.Text == "" || txtDOB.Text == "")
                {
                    MessageBox.Show("Inputs are not completed.", "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else if (!Regex.IsMatch(txtDOB.Text, dobValidate))
                {
                    MessageBox.Show("DOB input invalid. Use DD/MM/YYYY", "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else if (invalidCustID() == true)
                {
                    MessageBox.Show("Customer ID is already registered.", "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

                else
                {
                    int custID = int.Parse(txtCustID.Text);
                    string tit = txtTitle.Text;
                    string firName = txtFirstName.Text;
                    string lasName = txtLastName.Text;
                    string gen = txtGender.Text;
                    string dob = txtDOB.Text;

                    Customer newCustomer = new Customer(custID, tit, firName, lasName,
                   (Customer.Genders)Enum.Parse(typeof(Customer.Genders), gen), dob);

                    crm.AddCustomer(newCustomer);

                    MessageBox.Show("A customer has been added to the list.", "Add customer successful",
                    MessageBoxButtons.OK, MessageBoxIcon.Asterisk);

                    crm.SaveToFile();

                    txtCustID.Text = "";
                    txtTitle.Text = "";
                    txtFirstName.Text = "";
                    txtLastName.Text = "";
                    txtDOB.Text = "";
                    txtGender.Text = "";

                    LoadCustomersToGrid();
                }
            }
        }


        // Search functions for GUI
        private void searchInitiate(object sender, EventArgs e)
        {
            if (searchBox.Text == "Enter search query..")
            {
                searchButton.Enabled = true;
                searchBox.Text = "";
                searchBox.ForeColor = Color.Black;
            }
        }
        private void searchLeave(object sender, EventArgs e)
        {
            if (searchBox.Text == "")
            {
                searchButton.Enabled = false;
                searchBox.Text = "Enter search query..";
                searchBox.ForeColor = Color.Silver;
            }
        }

        private void searchButton_Click(object sender, EventArgs e)
        {
            createRentalGroupBox.Enabled = true;
            searchDataGridView.Visible = true;
            searchDataGridView.Rows.Clear();
            foreach (Vehicle vehicle in fleet.RetrieveVehicles(searchBox.Text))
            {
                searchDataGridView.Rows.Add(new string[] { vehicle.VehicleRego,  vehicle.Make,  vehicle.Model, vehicle.Year.ToString(), vehicle.VehicleClass.ToString(), vehicle.NumSeats.ToString(),
                  vehicle.TransmissionType.ToString(), vehicle.FuelType.ToString(), vehicle.GPS.ToString(), vehicle.SunRoof.ToString(), vehicle.DailyRate.ToString(), vehicle.Colour });
            }
        }

        private void showAllButton_Click(object sender, EventArgs e)
        {
            searchDataGridView.Rows.Clear();
            searchDataGridView.Visible = true;
            createRentalGroupBox.Enabled = true;


            foreach (Vehicle vehicle in fleet.RetrieveVehicles(false))
            {

                searchDataGridView.Rows.Add(new string[] { vehicle.VehicleRego,  vehicle.Make,  vehicle.Model, vehicle.Year.ToString(), vehicle.VehicleClass.ToString(), vehicle.NumSeats.ToString(),
                  vehicle.TransmissionType.ToString(), vehicle.FuelType.ToString(), vehicle.GPS.ToString(), vehicle.SunRoof.ToString(), vehicle.DailyRate.ToString(), vehicle.Colour });
            }

        }


        // Exits program, saves data to csv
        private void ExitMMRC(object sender, FormClosingEventArgs e)
        {
            fleet.SaveToFile();
            crm.SaveToFile();
        }

        // Limitations, Adhere to boundaries

        // Numbers only for year
        private void txtYear_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        // No numbers as inputs
        private void txtColour_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !(char.IsLetter(e.KeyChar) || e.KeyChar == (char)Keys.Back);
        }

        private void txtMake_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !(char.IsLetter(e.KeyChar) || e.KeyChar == (char)Keys.Back);
        }

        // Numbers only for ID
        private void txtCustID_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        // No numbers for title, names
        private void txtTitle_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !(char.IsLetter(e.KeyChar) || e.KeyChar == (char)Keys.Back);
        }

        private void txtFirstName_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !(char.IsLetter(e.KeyChar) || e.KeyChar == (char)Keys.Back);
        }

        private void txtLastName_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !(char.IsLetter(e.KeyChar) || e.KeyChar == (char)Keys.Back);
        }
    }
}
