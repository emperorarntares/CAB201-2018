﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

/* CAB201 Assignment: Mates Rates Rent a Car (MRRC)
 * 
 * Due Date: 27/05/2018 20:00
 * 
 * Authors:
 * 
 * Kevin Duong - n9934731
 * Bowen Guan  - n9169377
 * 
 * Version: 0.1
 * 
 * The program is for a car rental company called Mates Rates
 * Rent a Car (MRRC), that helps the operators of the company 
 * more efficiently manage their fleet of cars and their customers.
 * 
 */

namespace MRRC
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());
        }
    }
}
