﻿namespace MRRC
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl = new System.Windows.Forms.TabControl();
            this.fleetPage = new System.Windows.Forms.TabPage();
            this.modifyVehicleGroupBox = new System.Windows.Forms.GroupBox();
            this.numericUpDownDailyRate = new System.Windows.Forms.NumericUpDown();
            this.numericUpDownSeats = new System.Windows.Forms.NumericUpDown();
            this.submitFleetButton = new System.Windows.Forms.Button();
            this.closeButton = new System.Windows.Forms.Button();
            this.checkBoxGPS = new System.Windows.Forms.CheckBox();
            this.checkBoxSunRoof = new System.Windows.Forms.CheckBox();
            this.txtColour = new System.Windows.Forms.TextBox();
            this.txtYear = new System.Windows.Forms.TextBox();
            this.txtTransmission = new System.Windows.Forms.ComboBox();
            this.txtFuel = new System.Windows.Forms.ComboBox();
            this.txtClass = new System.Windows.Forms.ComboBox();
            this.txtModel = new System.Windows.Forms.TextBox();
            this.txtMake = new System.Windows.Forms.TextBox();
            this.txtRego = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.fleetGroupBox = new System.Windows.Forms.GroupBox();
            this.addFleet = new System.Windows.Forms.Button();
            this.removeFleet = new System.Windows.Forms.Button();
            this.modifyFleet = new System.Windows.Forms.Button();
            this.fleetDataGridView = new System.Windows.Forms.DataGridView();
            this.customersPage = new System.Windows.Forms.TabPage();
            this.modifyCustomerGroupBox = new System.Windows.Forms.GroupBox();
            this.txtTitleLabel = new System.Windows.Forms.Label();
            this.txtTitle = new System.Windows.Forms.TextBox();
            this.txtDOB = new System.Windows.Forms.TextBox();
            this.submitCustomerButton = new System.Windows.Forms.Button();
            this.closeButton2 = new System.Windows.Forms.Button();
            this.txtGender = new System.Windows.Forms.ComboBox();
            this.txtLastName = new System.Windows.Forms.TextBox();
            this.txtFirstName = new System.Windows.Forms.TextBox();
            this.txtCustID = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.modifyCRMgroupBox = new System.Windows.Forms.GroupBox();
            this.addCustomer = new System.Windows.Forms.Button();
            this.removeCustomer = new System.Windows.Forms.Button();
            this.modifyCustomer = new System.Windows.Forms.Button();
            this.customersDataGridView = new System.Windows.Forms.DataGridView();
            this.rentalReportPage = new System.Windows.Forms.TabPage();
            this.modifyRentalGroupBox = new System.Windows.Forms.GroupBox();
            this.totalDailyRentalChargeLabel = new System.Windows.Forms.Label();
            this.dailychargelabel = new System.Windows.Forms.Label();
            this.totalVehiclesRentedLabel = new System.Windows.Forms.Label();
            this.rentedcarlabel = new System.Windows.Forms.Label();
            this.returnVechicleButton = new System.Windows.Forms.Button();
            this.reportDataGridView = new System.Windows.Forms.DataGridView();
            this.rentalSearchPage = new System.Windows.Forms.TabPage();
            this.createRentalGroupBox = new System.Windows.Forms.GroupBox();
            this.rentSearch = new System.Windows.Forms.Button();
            this.totalCost = new System.Windows.Forms.Label();
            this.totalcostLabel1 = new System.Windows.Forms.Label();
            this.numericUpDown3 = new System.Windows.Forms.NumericUpDown();
            this.customerCreateRental = new System.Windows.Forms.ComboBox();
            this.rentalDurationLabel1 = new System.Windows.Forms.Label();
            this.customerLabel1 = new System.Windows.Forms.Label();
            this.tolabel = new System.Windows.Forms.Label();
            this.numericUpDown2 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown1 = new System.Windows.Forms.NumericUpDown();
            this.rangeLabel = new System.Windows.Forms.Label();
            this.showAllButton = new System.Windows.Forms.Button();
            this.searchButton = new System.Windows.Forms.Button();
            this.searchBox = new System.Windows.Forms.TextBox();
            this.searchDataGridView = new System.Windows.Forms.DataGridView();
            this.titleLable = new System.Windows.Forms.Label();
            this.managementLabel = new System.Windows.Forms.Label();
            this.tabControl.SuspendLayout();
            this.fleetPage.SuspendLayout();
            this.modifyVehicleGroupBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownDailyRate)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownSeats)).BeginInit();
            this.fleetGroupBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fleetDataGridView)).BeginInit();
            this.customersPage.SuspendLayout();
            this.modifyCustomerGroupBox.SuspendLayout();
            this.modifyCRMgroupBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.customersDataGridView)).BeginInit();
            this.rentalReportPage.SuspendLayout();
            this.modifyRentalGroupBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.reportDataGridView)).BeginInit();
            this.rentalSearchPage.SuspendLayout();
            this.createRentalGroupBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.searchDataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl
            // 
            this.tabControl.Controls.Add(this.fleetPage);
            this.tabControl.Controls.Add(this.customersPage);
            this.tabControl.Controls.Add(this.rentalReportPage);
            this.tabControl.Controls.Add(this.rentalSearchPage);
            this.tabControl.Location = new System.Drawing.Point(0, 60);
            this.tabControl.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tabControl.Name = "tabControl";
            this.tabControl.SelectedIndex = 0;
            this.tabControl.Size = new System.Drawing.Size(1200, 742);
            this.tabControl.SizeMode = System.Windows.Forms.TabSizeMode.Fixed;
            this.tabControl.TabIndex = 0;
            // 
            // fleetPage
            // 
            this.fleetPage.Controls.Add(this.modifyVehicleGroupBox);
            this.fleetPage.Controls.Add(this.fleetGroupBox);
            this.fleetPage.Controls.Add(this.fleetDataGridView);
            this.fleetPage.Location = new System.Drawing.Point(4, 25);
            this.fleetPage.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.fleetPage.Name = "fleetPage";
            this.fleetPage.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.fleetPage.Size = new System.Drawing.Size(1192, 713);
            this.fleetPage.TabIndex = 0;
            this.fleetPage.Text = "Fleet";
            this.fleetPage.UseVisualStyleBackColor = true;
            // 
            // modifyVehicleGroupBox
            // 
            this.modifyVehicleGroupBox.Controls.Add(this.numericUpDownDailyRate);
            this.modifyVehicleGroupBox.Controls.Add(this.numericUpDownSeats);
            this.modifyVehicleGroupBox.Controls.Add(this.submitFleetButton);
            this.modifyVehicleGroupBox.Controls.Add(this.closeButton);
            this.modifyVehicleGroupBox.Controls.Add(this.checkBoxGPS);
            this.modifyVehicleGroupBox.Controls.Add(this.checkBoxSunRoof);
            this.modifyVehicleGroupBox.Controls.Add(this.txtColour);
            this.modifyVehicleGroupBox.Controls.Add(this.txtYear);
            this.modifyVehicleGroupBox.Controls.Add(this.txtTransmission);
            this.modifyVehicleGroupBox.Controls.Add(this.txtFuel);
            this.modifyVehicleGroupBox.Controls.Add(this.txtClass);
            this.modifyVehicleGroupBox.Controls.Add(this.txtModel);
            this.modifyVehicleGroupBox.Controls.Add(this.txtMake);
            this.modifyVehicleGroupBox.Controls.Add(this.txtRego);
            this.modifyVehicleGroupBox.Controls.Add(this.label1);
            this.modifyVehicleGroupBox.Controls.Add(this.label2);
            this.modifyVehicleGroupBox.Controls.Add(this.label3);
            this.modifyVehicleGroupBox.Controls.Add(this.label4);
            this.modifyVehicleGroupBox.Controls.Add(this.label5);
            this.modifyVehicleGroupBox.Controls.Add(this.label6);
            this.modifyVehicleGroupBox.Controls.Add(this.label7);
            this.modifyVehicleGroupBox.Controls.Add(this.label8);
            this.modifyVehicleGroupBox.Controls.Add(this.label9);
            this.modifyVehicleGroupBox.Controls.Add(this.label10);
            this.modifyVehicleGroupBox.Controls.Add(this.label11);
            this.modifyVehicleGroupBox.Controls.Add(this.label12);
            this.modifyVehicleGroupBox.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.modifyVehicleGroupBox.Location = new System.Drawing.Point(3, 437);
            this.modifyVehicleGroupBox.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.modifyVehicleGroupBox.Name = "modifyVehicleGroupBox";
            this.modifyVehicleGroupBox.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.modifyVehicleGroupBox.Size = new System.Drawing.Size(1186, 200);
            this.modifyVehicleGroupBox.TabIndex = 4;
            this.modifyVehicleGroupBox.TabStop = false;
            this.modifyVehicleGroupBox.Text = "Modify Vehicle";
            this.modifyVehicleGroupBox.Visible = false;
            // 
            // numericUpDownDailyRate
            // 
            this.numericUpDownDailyRate.Location = new System.Drawing.Point(867, 108);
            this.numericUpDownDailyRate.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.numericUpDownDailyRate.Maximum = new decimal(new int[] {
            999999999,
            0,
            0,
            0});
            this.numericUpDownDailyRate.Name = "numericUpDownDailyRate";
            this.numericUpDownDailyRate.Size = new System.Drawing.Size(71, 22);
            this.numericUpDownDailyRate.TabIndex = 28;
            // 
            // numericUpDownSeats
            // 
            this.numericUpDownSeats.Location = new System.Drawing.Point(509, 149);
            this.numericUpDownSeats.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.numericUpDownSeats.Maximum = new decimal(new int[] {
            20,
            0,
            0,
            0});
            this.numericUpDownSeats.Name = "numericUpDownSeats";
            this.numericUpDownSeats.Size = new System.Drawing.Size(71, 22);
            this.numericUpDownSeats.TabIndex = 27;
            // 
            // submitFleetButton
            // 
            this.submitFleetButton.Location = new System.Drawing.Point(891, 149);
            this.submitFleetButton.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.submitFleetButton.Name = "submitFleetButton";
            this.submitFleetButton.Size = new System.Drawing.Size(107, 38);
            this.submitFleetButton.TabIndex = 26;
            this.submitFleetButton.Text = "Submit";
            this.submitFleetButton.UseVisualStyleBackColor = true;
            this.submitFleetButton.Click += new System.EventHandler(this.submitFleetButton_Click);
            // 
            // closeButton
            // 
            this.closeButton.Location = new System.Drawing.Point(1020, 149);
            this.closeButton.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.closeButton.Name = "closeButton";
            this.closeButton.Size = new System.Drawing.Size(107, 38);
            this.closeButton.TabIndex = 3;
            this.closeButton.Text = "Close";
            this.closeButton.UseVisualStyleBackColor = true;
            this.closeButton.Click += new System.EventHandler(this.closeButton_Click);
            // 
            // checkBoxGPS
            // 
            this.checkBoxGPS.AutoSize = true;
            this.checkBoxGPS.Location = new System.Drawing.Point(1017, 37);
            this.checkBoxGPS.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.checkBoxGPS.Name = "checkBoxGPS";
            this.checkBoxGPS.Size = new System.Drawing.Size(18, 17);
            this.checkBoxGPS.TabIndex = 25;
            this.checkBoxGPS.UseVisualStyleBackColor = true;
            // 
            // checkBoxSunRoof
            // 
            this.checkBoxSunRoof.AutoSize = true;
            this.checkBoxSunRoof.Location = new System.Drawing.Point(867, 37);
            this.checkBoxSunRoof.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.checkBoxSunRoof.Name = "checkBoxSunRoof";
            this.checkBoxSunRoof.Size = new System.Drawing.Size(18, 17);
            this.checkBoxSunRoof.TabIndex = 24;
            this.checkBoxSunRoof.UseVisualStyleBackColor = true;
            // 
            // txtColour
            // 
            this.txtColour.Location = new System.Drawing.Point(867, 72);
            this.txtColour.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtColour.MaxLength = 25;
            this.txtColour.Name = "txtColour";
            this.txtColour.Size = new System.Drawing.Size(169, 22);
            this.txtColour.TabIndex = 22;
            this.txtColour.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtColour_KeyPress);
            // 
            // txtYear
            // 
            this.txtYear.Location = new System.Drawing.Point(509, 33);
            this.txtYear.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtYear.MaxLength = 4;
            this.txtYear.Name = "txtYear";
            this.txtYear.Size = new System.Drawing.Size(91, 22);
            this.txtYear.TabIndex = 20;
            this.txtYear.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtYear_KeyPress);
            // 
            // txtTransmission
            // 
            this.txtTransmission.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.txtTransmission.FormattingEnabled = true;
            this.txtTransmission.Items.AddRange(new object[] {
            "",
            "Automatic",
            "Manual"});
            this.txtTransmission.Location = new System.Drawing.Point(509, 72);
            this.txtTransmission.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtTransmission.Name = "txtTransmission";
            this.txtTransmission.Size = new System.Drawing.Size(169, 24);
            this.txtTransmission.TabIndex = 19;
            // 
            // txtFuel
            // 
            this.txtFuel.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.txtFuel.FormattingEnabled = true;
            this.txtFuel.Items.AddRange(new object[] {
            "",
            "Petrol",
            "Diesel"});
            this.txtFuel.Location = new System.Drawing.Point(509, 112);
            this.txtFuel.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtFuel.Name = "txtFuel";
            this.txtFuel.Size = new System.Drawing.Size(169, 24);
            this.txtFuel.TabIndex = 18;
            // 
            // txtClass
            // 
            this.txtClass.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.txtClass.FormattingEnabled = true;
            this.txtClass.Items.AddRange(new object[] {
            "",
            "Economy",
            "Family",
            "Luxury",
            "Commercial"});
            this.txtClass.Location = new System.Drawing.Point(97, 141);
            this.txtClass.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtClass.Name = "txtClass";
            this.txtClass.Size = new System.Drawing.Size(169, 24);
            this.txtClass.TabIndex = 17;
            // 
            // txtModel
            // 
            this.txtModel.Location = new System.Drawing.Point(97, 107);
            this.txtModel.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtModel.MaxLength = 25;
            this.txtModel.Name = "txtModel";
            this.txtModel.Size = new System.Drawing.Size(169, 22);
            this.txtModel.TabIndex = 14;
            // 
            // txtMake
            // 
            this.txtMake.Location = new System.Drawing.Point(97, 70);
            this.txtMake.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtMake.MaxLength = 25;
            this.txtMake.Name = "txtMake";
            this.txtMake.Size = new System.Drawing.Size(169, 22);
            this.txtMake.TabIndex = 13;
            this.txtMake.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtMake_KeyPress);
            // 
            // txtRego
            // 
            this.txtRego.Location = new System.Drawing.Point(97, 33);
            this.txtRego.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtRego.MaxLength = 6;
            this.txtRego.Name = "txtRego";
            this.txtRego.Size = new System.Drawing.Size(91, 22);
            this.txtRego.TabIndex = 12;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label1.Location = new System.Drawing.Point(772, 112);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(88, 17);
            this.label1.TabIndex = 11;
            this.label1.Text = "Daily Rate:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label2.Location = new System.Drawing.Point(800, 75);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(60, 17);
            this.label2.TabIndex = 10;
            this.label2.Text = "Colour:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label3.Location = new System.Drawing.Point(965, 37);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(45, 17);
            this.label3.TabIndex = 9;
            this.label3.Text = "GPS:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label4.Location = new System.Drawing.Point(789, 38);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(70, 17);
            this.label4.TabIndex = 8;
            this.label4.Text = "Sunroof:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label5.Location = new System.Drawing.Point(432, 149);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(54, 17);
            this.label5.TabIndex = 7;
            this.label5.Text = "Seats:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label6.Location = new System.Drawing.Point(443, 112);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(44, 17);
            this.label6.TabIndex = 6;
            this.label6.Text = "Fuel:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label7.Location = new System.Drawing.Point(377, 75);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(109, 17);
            this.label7.TabIndex = 5;
            this.label7.Text = "Transmission:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label8.Location = new System.Drawing.Point(439, 38);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(47, 17);
            this.label8.TabIndex = 4;
            this.label8.Text = "Year:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label9.Location = new System.Drawing.Point(16, 148);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(52, 17);
            this.label9.TabIndex = 3;
            this.label9.Text = "Class:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label10.Location = new System.Drawing.Point(13, 112);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(56, 17);
            this.label10.TabIndex = 2;
            this.label10.Text = "Model:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label11.Location = new System.Drawing.Point(19, 75);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(51, 17);
            this.label11.TabIndex = 1;
            this.label11.Text = "Make:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label12.Location = new System.Drawing.Point(19, 38);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(51, 17);
            this.label12.TabIndex = 0;
            this.label12.Text = "Rego:";
            // 
            // fleetGroupBox
            // 
            this.fleetGroupBox.Controls.Add(this.addFleet);
            this.fleetGroupBox.Controls.Add(this.removeFleet);
            this.fleetGroupBox.Controls.Add(this.modifyFleet);
            this.fleetGroupBox.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.fleetGroupBox.Location = new System.Drawing.Point(3, 637);
            this.fleetGroupBox.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.fleetGroupBox.Name = "fleetGroupBox";
            this.fleetGroupBox.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.fleetGroupBox.Size = new System.Drawing.Size(1186, 72);
            this.fleetGroupBox.TabIndex = 1;
            this.fleetGroupBox.TabStop = false;
            this.fleetGroupBox.Text = "Modify fleet";
            // 
            // addFleet
            // 
            this.addFleet.Location = new System.Drawing.Point(1020, 21);
            this.addFleet.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.addFleet.Name = "addFleet";
            this.addFleet.Size = new System.Drawing.Size(107, 38);
            this.addFleet.TabIndex = 2;
            this.addFleet.Text = "Add";
            this.addFleet.UseVisualStyleBackColor = true;
            this.addFleet.Click += new System.EventHandler(this.addFleet_Click);
            // 
            // removeFleet
            // 
            this.removeFleet.Location = new System.Drawing.Point(133, 24);
            this.removeFleet.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.removeFleet.Name = "removeFleet";
            this.removeFleet.Size = new System.Drawing.Size(119, 38);
            this.removeFleet.TabIndex = 1;
            this.removeFleet.Text = "Remove";
            this.removeFleet.UseVisualStyleBackColor = true;
            this.removeFleet.Click += new System.EventHandler(this.removeFleet_Click);
            // 
            // modifyFleet
            // 
            this.modifyFleet.Location = new System.Drawing.Point(5, 24);
            this.modifyFleet.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.modifyFleet.Name = "modifyFleet";
            this.modifyFleet.Size = new System.Drawing.Size(115, 38);
            this.modifyFleet.TabIndex = 0;
            this.modifyFleet.Text = "Modify";
            this.modifyFleet.UseVisualStyleBackColor = true;
            this.modifyFleet.Click += new System.EventHandler(this.modifyFleet_Click);
            // 
            // fleetDataGridView
            // 
            this.fleetDataGridView.AllowUserToAddRows = false;
            this.fleetDataGridView.AllowUserToDeleteRows = false;
            this.fleetDataGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.fleetDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.fleetDataGridView.Location = new System.Drawing.Point(3, 4);
            this.fleetDataGridView.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.fleetDataGridView.MultiSelect = false;
            this.fleetDataGridView.Name = "fleetDataGridView";
            this.fleetDataGridView.ReadOnly = true;
            this.fleetDataGridView.RowTemplate.Height = 24;
            this.fleetDataGridView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.fleetDataGridView.Size = new System.Drawing.Size(1186, 438);
            this.fleetDataGridView.TabIndex = 3;
            this.fleetDataGridView.SelectionChanged += new System.EventHandler(this.fleetDataGridView_SelectionChanged);
            // 
            // customersPage
            // 
            this.customersPage.Controls.Add(this.modifyCustomerGroupBox);
            this.customersPage.Controls.Add(this.modifyCRMgroupBox);
            this.customersPage.Controls.Add(this.customersDataGridView);
            this.customersPage.Location = new System.Drawing.Point(4, 25);
            this.customersPage.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.customersPage.Name = "customersPage";
            this.customersPage.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.customersPage.Size = new System.Drawing.Size(1192, 713);
            this.customersPage.TabIndex = 1;
            this.customersPage.Text = "Customers";
            this.customersPage.UseVisualStyleBackColor = true;
            // 
            // modifyCustomerGroupBox
            // 
            this.modifyCustomerGroupBox.Controls.Add(this.txtTitleLabel);
            this.modifyCustomerGroupBox.Controls.Add(this.txtTitle);
            this.modifyCustomerGroupBox.Controls.Add(this.txtDOB);
            this.modifyCustomerGroupBox.Controls.Add(this.submitCustomerButton);
            this.modifyCustomerGroupBox.Controls.Add(this.closeButton2);
            this.modifyCustomerGroupBox.Controls.Add(this.txtGender);
            this.modifyCustomerGroupBox.Controls.Add(this.txtLastName);
            this.modifyCustomerGroupBox.Controls.Add(this.txtFirstName);
            this.modifyCustomerGroupBox.Controls.Add(this.txtCustID);
            this.modifyCustomerGroupBox.Controls.Add(this.label19);
            this.modifyCustomerGroupBox.Controls.Add(this.label21);
            this.modifyCustomerGroupBox.Controls.Add(this.label22);
            this.modifyCustomerGroupBox.Controls.Add(this.label23);
            this.modifyCustomerGroupBox.Controls.Add(this.label24);
            this.modifyCustomerGroupBox.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.modifyCustomerGroupBox.Location = new System.Drawing.Point(3, 437);
            this.modifyCustomerGroupBox.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.modifyCustomerGroupBox.Name = "modifyCustomerGroupBox";
            this.modifyCustomerGroupBox.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.modifyCustomerGroupBox.Size = new System.Drawing.Size(1186, 200);
            this.modifyCustomerGroupBox.TabIndex = 5;
            this.modifyCustomerGroupBox.TabStop = false;
            this.modifyCustomerGroupBox.Text = "Modify Customer";
            this.modifyCustomerGroupBox.Visible = false;
            // 
            // txtTitleLabel
            // 
            this.txtTitleLabel.AutoSize = true;
            this.txtTitleLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txtTitleLabel.Location = new System.Drawing.Point(172, 42);
            this.txtTitleLabel.Name = "txtTitleLabel";
            this.txtTitleLabel.Size = new System.Drawing.Size(45, 17);
            this.txtTitleLabel.TabIndex = 29;
            this.txtTitleLabel.Text = "Title:";
            // 
            // txtTitle
            // 
            this.txtTitle.Location = new System.Drawing.Point(171, 61);
            this.txtTitle.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtTitle.MaxLength = 4;
            this.txtTitle.Name = "txtTitle";
            this.txtTitle.Size = new System.Drawing.Size(91, 22);
            this.txtTitle.TabIndex = 28;
            this.txtTitle.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtTitle_KeyPress);
            // 
            // txtDOB
            // 
            this.txtDOB.Location = new System.Drawing.Point(489, 61);
            this.txtDOB.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtDOB.MaxLength = 10;
            this.txtDOB.Name = "txtDOB";
            this.txtDOB.Size = new System.Drawing.Size(169, 22);
            this.txtDOB.TabIndex = 27;
            // 
            // submitCustomerButton
            // 
            this.submitCustomerButton.Location = new System.Drawing.Point(891, 149);
            this.submitCustomerButton.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.submitCustomerButton.Name = "submitCustomerButton";
            this.submitCustomerButton.Size = new System.Drawing.Size(107, 38);
            this.submitCustomerButton.TabIndex = 26;
            this.submitCustomerButton.Text = "Submit";
            this.submitCustomerButton.UseVisualStyleBackColor = true;
            this.submitCustomerButton.Click += new System.EventHandler(this.submitCustomerButton_Click);
            // 
            // closeButton2
            // 
            this.closeButton2.Location = new System.Drawing.Point(1020, 149);
            this.closeButton2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.closeButton2.Name = "closeButton2";
            this.closeButton2.Size = new System.Drawing.Size(107, 38);
            this.closeButton2.TabIndex = 3;
            this.closeButton2.Text = "Close";
            this.closeButton2.UseVisualStyleBackColor = true;
            this.closeButton2.Click += new System.EventHandler(this.closeButton2_Click);
            // 
            // txtGender
            // 
            this.txtGender.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.txtGender.FormattingEnabled = true;
            this.txtGender.Items.AddRange(new object[] {
            "Male",
            "Female"});
            this.txtGender.Location = new System.Drawing.Point(489, 111);
            this.txtGender.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtGender.Name = "txtGender";
            this.txtGender.Size = new System.Drawing.Size(169, 24);
            this.txtGender.TabIndex = 19;
            // 
            // txtLastName
            // 
            this.txtLastName.Location = new System.Drawing.Point(36, 160);
            this.txtLastName.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtLastName.MaxLength = 25;
            this.txtLastName.Name = "txtLastName";
            this.txtLastName.Size = new System.Drawing.Size(369, 22);
            this.txtLastName.TabIndex = 14;
            this.txtLastName.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtLastName_KeyPress);
            // 
            // txtFirstName
            // 
            this.txtFirstName.Location = new System.Drawing.Point(36, 112);
            this.txtFirstName.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtFirstName.MaxLength = 25;
            this.txtFirstName.Name = "txtFirstName";
            this.txtFirstName.Size = new System.Drawing.Size(369, 22);
            this.txtFirstName.TabIndex = 13;
            this.txtFirstName.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtFirstName_KeyPress);
            // 
            // txtCustID
            // 
            this.txtCustID.Location = new System.Drawing.Point(36, 61);
            this.txtCustID.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtCustID.Name = "txtCustID";
            this.txtCustID.Size = new System.Drawing.Size(91, 22);
            this.txtCustID.TabIndex = 12;
            this.txtCustID.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtCustID_KeyPress);
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label19.Location = new System.Drawing.Point(485, 92);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(67, 17);
            this.label19.TabIndex = 5;
            this.label19.Text = "Gender:";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label21.Location = new System.Drawing.Point(485, 42);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(105, 17);
            this.label21.TabIndex = 3;
            this.label21.Text = "Date of Birth:";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label22.Location = new System.Drawing.Point(32, 140);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(90, 17);
            this.label22.TabIndex = 2;
            this.label22.Text = "Last Name:";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label23.Location = new System.Drawing.Point(32, 92);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(91, 17);
            this.label23.TabIndex = 1;
            this.label23.Text = "First Name:";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label24.Location = new System.Drawing.Point(32, 42);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(67, 17);
            this.label24.TabIndex = 0;
            this.label24.Text = "User ID:";
            // 
            // modifyCRMgroupBox
            // 
            this.modifyCRMgroupBox.Controls.Add(this.addCustomer);
            this.modifyCRMgroupBox.Controls.Add(this.removeCustomer);
            this.modifyCRMgroupBox.Controls.Add(this.modifyCustomer);
            this.modifyCRMgroupBox.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.modifyCRMgroupBox.Location = new System.Drawing.Point(3, 637);
            this.modifyCRMgroupBox.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.modifyCRMgroupBox.Name = "modifyCRMgroupBox";
            this.modifyCRMgroupBox.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.modifyCRMgroupBox.Size = new System.Drawing.Size(1186, 72);
            this.modifyCRMgroupBox.TabIndex = 1;
            this.modifyCRMgroupBox.TabStop = false;
            this.modifyCRMgroupBox.Text = "Modify CRM";
            // 
            // addCustomer
            // 
            this.addCustomer.Location = new System.Drawing.Point(1020, 21);
            this.addCustomer.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.addCustomer.Name = "addCustomer";
            this.addCustomer.Size = new System.Drawing.Size(107, 38);
            this.addCustomer.TabIndex = 2;
            this.addCustomer.Text = "Add";
            this.addCustomer.UseVisualStyleBackColor = true;
            this.addCustomer.Click += new System.EventHandler(this.addCustomer_Click);
            // 
            // removeCustomer
            // 
            this.removeCustomer.Location = new System.Drawing.Point(129, 20);
            this.removeCustomer.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.removeCustomer.Name = "removeCustomer";
            this.removeCustomer.Size = new System.Drawing.Size(115, 40);
            this.removeCustomer.TabIndex = 1;
            this.removeCustomer.Text = "Remove";
            this.removeCustomer.UseVisualStyleBackColor = true;
            this.removeCustomer.Click += new System.EventHandler(this.removeCustomer_Click);
            // 
            // modifyCustomer
            // 
            this.modifyCustomer.Location = new System.Drawing.Point(5, 21);
            this.modifyCustomer.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.modifyCustomer.Name = "modifyCustomer";
            this.modifyCustomer.Size = new System.Drawing.Size(115, 38);
            this.modifyCustomer.TabIndex = 0;
            this.modifyCustomer.Text = "Modify";
            this.modifyCustomer.UseVisualStyleBackColor = true;
            this.modifyCustomer.Click += new System.EventHandler(this.modifyCustomer_Click);
            // 
            // customersDataGridView
            // 
            this.customersDataGridView.AllowUserToAddRows = false;
            this.customersDataGridView.AllowUserToDeleteRows = false;
            this.customersDataGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.customersDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.customersDataGridView.Location = new System.Drawing.Point(3, 4);
            this.customersDataGridView.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.customersDataGridView.MultiSelect = false;
            this.customersDataGridView.Name = "customersDataGridView";
            this.customersDataGridView.ReadOnly = true;
            this.customersDataGridView.RowTemplate.Height = 24;
            this.customersDataGridView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.customersDataGridView.Size = new System.Drawing.Size(1186, 434);
            this.customersDataGridView.TabIndex = 2;
            this.customersDataGridView.SelectionChanged += new System.EventHandler(this.customersDataGridView_SelectionChanged);
            // 
            // rentalReportPage
            // 
            this.rentalReportPage.Controls.Add(this.modifyRentalGroupBox);
            this.rentalReportPage.Controls.Add(this.reportDataGridView);
            this.rentalReportPage.Location = new System.Drawing.Point(4, 25);
            this.rentalReportPage.Name = "rentalReportPage";
            this.rentalReportPage.Size = new System.Drawing.Size(1192, 713);
            this.rentalReportPage.TabIndex = 2;
            this.rentalReportPage.Text = "Rental Report";
            this.rentalReportPage.UseVisualStyleBackColor = true;
            // 
            // modifyRentalGroupBox
            // 
            this.modifyRentalGroupBox.Controls.Add(this.totalDailyRentalChargeLabel);
            this.modifyRentalGroupBox.Controls.Add(this.dailychargelabel);
            this.modifyRentalGroupBox.Controls.Add(this.totalVehiclesRentedLabel);
            this.modifyRentalGroupBox.Controls.Add(this.rentedcarlabel);
            this.modifyRentalGroupBox.Controls.Add(this.returnVechicleButton);
            this.modifyRentalGroupBox.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.modifyRentalGroupBox.Location = new System.Drawing.Point(0, 641);
            this.modifyRentalGroupBox.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.modifyRentalGroupBox.Name = "modifyRentalGroupBox";
            this.modifyRentalGroupBox.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.modifyRentalGroupBox.Size = new System.Drawing.Size(1192, 72);
            this.modifyRentalGroupBox.TabIndex = 1;
            this.modifyRentalGroupBox.TabStop = false;
            this.modifyRentalGroupBox.Text = "Modify Rentals";
            // 
            // totalDailyRentalChargeLabel
            // 
            this.totalDailyRentalChargeLabel.AutoSize = true;
            this.totalDailyRentalChargeLabel.Location = new System.Drawing.Point(1036, 29);
            this.totalDailyRentalChargeLabel.Name = "totalDailyRentalChargeLabel";
            this.totalDailyRentalChargeLabel.Size = new System.Drawing.Size(52, 17);
            this.totalDailyRentalChargeLabel.TabIndex = 4;
            this.totalDailyRentalChargeLabel.Text = "$00.00";
            // 
            // dailychargelabel
            // 
            this.dailychargelabel.AutoSize = true;
            this.dailychargelabel.Location = new System.Drawing.Point(853, 29);
            this.dailychargelabel.Name = "dailychargelabel";
            this.dailychargelabel.Size = new System.Drawing.Size(165, 17);
            this.dailychargelabel.TabIndex = 3;
            this.dailychargelabel.Text = "Total daily rental charge:";
            // 
            // totalVehiclesRentedLabel
            // 
            this.totalVehiclesRentedLabel.AutoSize = true;
            this.totalVehiclesRentedLabel.Location = new System.Drawing.Point(799, 29);
            this.totalVehiclesRentedLabel.Name = "totalVehiclesRentedLabel";
            this.totalVehiclesRentedLabel.Size = new System.Drawing.Size(16, 17);
            this.totalVehiclesRentedLabel.TabIndex = 2;
            this.totalVehiclesRentedLabel.Text = "0";
            // 
            // rentedcarlabel
            // 
            this.rentedcarlabel.AutoSize = true;
            this.rentedcarlabel.Location = new System.Drawing.Point(649, 29);
            this.rentedcarlabel.Name = "rentedcarlabel";
            this.rentedcarlabel.Size = new System.Drawing.Size(144, 17);
            this.rentedcarlabel.TabIndex = 1;
            this.rentedcarlabel.Text = "Total vehicles rented:";
            // 
            // returnVechicleButton
            // 
            this.returnVechicleButton.Location = new System.Drawing.Point(15, 29);
            this.returnVechicleButton.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.returnVechicleButton.Name = "returnVechicleButton";
            this.returnVechicleButton.Size = new System.Drawing.Size(128, 37);
            this.returnVechicleButton.TabIndex = 0;
            this.returnVechicleButton.Text = "Return vehicle";
            this.returnVechicleButton.UseVisualStyleBackColor = true;
            // 
            // reportDataGridView
            // 
            this.reportDataGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.reportDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.reportDataGridView.Location = new System.Drawing.Point(0, 0);
            this.reportDataGridView.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.reportDataGridView.MultiSelect = false;
            this.reportDataGridView.Name = "reportDataGridView";
            this.reportDataGridView.ReadOnly = true;
            this.reportDataGridView.RowTemplate.Height = 24;
            this.reportDataGridView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.reportDataGridView.Size = new System.Drawing.Size(1189, 633);
            this.reportDataGridView.TabIndex = 3;
            // 
            // rentalSearchPage
            // 
            this.rentalSearchPage.Controls.Add(this.createRentalGroupBox);
            this.rentalSearchPage.Controls.Add(this.tolabel);
            this.rentalSearchPage.Controls.Add(this.numericUpDown2);
            this.rentalSearchPage.Controls.Add(this.numericUpDown1);
            this.rentalSearchPage.Controls.Add(this.rangeLabel);
            this.rentalSearchPage.Controls.Add(this.showAllButton);
            this.rentalSearchPage.Controls.Add(this.searchButton);
            this.rentalSearchPage.Controls.Add(this.searchBox);
            this.rentalSearchPage.Controls.Add(this.searchDataGridView);
            this.rentalSearchPage.Location = new System.Drawing.Point(4, 25);
            this.rentalSearchPage.Name = "rentalSearchPage";
            this.rentalSearchPage.Size = new System.Drawing.Size(1192, 713);
            this.rentalSearchPage.TabIndex = 3;
            this.rentalSearchPage.Text = "Rental Search";
            this.rentalSearchPage.UseVisualStyleBackColor = true;
            // 
            // createRentalGroupBox
            // 
            this.createRentalGroupBox.Controls.Add(this.rentSearch);
            this.createRentalGroupBox.Controls.Add(this.totalCost);
            this.createRentalGroupBox.Controls.Add(this.totalcostLabel1);
            this.createRentalGroupBox.Controls.Add(this.numericUpDown3);
            this.createRentalGroupBox.Controls.Add(this.customerCreateRental);
            this.createRentalGroupBox.Controls.Add(this.rentalDurationLabel1);
            this.createRentalGroupBox.Controls.Add(this.customerLabel1);
            this.createRentalGroupBox.Enabled = false;
            this.createRentalGroupBox.Location = new System.Drawing.Point(0, 559);
            this.createRentalGroupBox.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.createRentalGroupBox.Name = "createRentalGroupBox";
            this.createRentalGroupBox.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.createRentalGroupBox.Size = new System.Drawing.Size(1137, 125);
            this.createRentalGroupBox.TabIndex = 8;
            this.createRentalGroupBox.TabStop = false;
            this.createRentalGroupBox.Text = "Create rental";
            // 
            // rentSearch
            // 
            this.rentSearch.Location = new System.Drawing.Point(432, 61);
            this.rentSearch.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.rentSearch.Name = "rentSearch";
            this.rentSearch.Size = new System.Drawing.Size(84, 40);
            this.rentSearch.TabIndex = 9;
            this.rentSearch.Text = "Rent";
            this.rentSearch.UseVisualStyleBackColor = true;
            // 
            // totalCost
            // 
            this.totalCost.AutoSize = true;
            this.totalCost.Location = new System.Drawing.Point(341, 84);
            this.totalCost.Name = "totalCost";
            this.totalCost.Size = new System.Drawing.Size(52, 17);
            this.totalCost.TabIndex = 8;
            this.totalCost.Text = "$00.00";
            // 
            // totalcostLabel1
            // 
            this.totalcostLabel1.AutoSize = true;
            this.totalcostLabel1.Location = new System.Drawing.Point(261, 84);
            this.totalcostLabel1.Name = "totalcostLabel1";
            this.totalcostLabel1.Size = new System.Drawing.Size(74, 17);
            this.totalcostLabel1.TabIndex = 7;
            this.totalcostLabel1.Text = "Total cost:";
            // 
            // numericUpDown3
            // 
            this.numericUpDown3.Location = new System.Drawing.Point(149, 79);
            this.numericUpDown3.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.numericUpDown3.Name = "numericUpDown3";
            this.numericUpDown3.Size = new System.Drawing.Size(59, 22);
            this.numericUpDown3.TabIndex = 6;
            // 
            // customerCreateRental
            // 
            this.customerCreateRental.FormattingEnabled = true;
            this.customerCreateRental.Location = new System.Drawing.Point(149, 44);
            this.customerCreateRental.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.customerCreateRental.Name = "customerCreateRental";
            this.customerCreateRental.Size = new System.Drawing.Size(121, 24);
            this.customerCreateRental.TabIndex = 2;
            // 
            // rentalDurationLabel1
            // 
            this.rentalDurationLabel1.AutoSize = true;
            this.rentalDurationLabel1.Location = new System.Drawing.Point(28, 84);
            this.rentalDurationLabel1.Name = "rentalDurationLabel1";
            this.rentalDurationLabel1.Size = new System.Drawing.Size(109, 17);
            this.rentalDurationLabel1.TabIndex = 1;
            this.rentalDurationLabel1.Text = "Rental duration:";
            // 
            // customerLabel1
            // 
            this.customerLabel1.AutoSize = true;
            this.customerLabel1.Location = new System.Drawing.Point(28, 44);
            this.customerLabel1.Name = "customerLabel1";
            this.customerLabel1.Size = new System.Drawing.Size(72, 17);
            this.customerLabel1.TabIndex = 0;
            this.customerLabel1.Text = "Customer:";
            // 
            // tolabel
            // 
            this.tolabel.AutoSize = true;
            this.tolabel.Location = new System.Drawing.Point(225, 60);
            this.tolabel.Name = "tolabel";
            this.tolabel.Size = new System.Drawing.Size(13, 17);
            this.tolabel.TabIndex = 6;
            this.tolabel.Text = "-";
            // 
            // numericUpDown2
            // 
            this.numericUpDown2.Location = new System.Drawing.Point(244, 58);
            this.numericUpDown2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.numericUpDown2.Name = "numericUpDown2";
            this.numericUpDown2.Size = new System.Drawing.Size(75, 22);
            this.numericUpDown2.TabIndex = 5;
            // 
            // numericUpDown1
            // 
            this.numericUpDown1.Location = new System.Drawing.Point(149, 58);
            this.numericUpDown1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.numericUpDown1.Name = "numericUpDown1";
            this.numericUpDown1.Size = new System.Drawing.Size(71, 22);
            this.numericUpDown1.TabIndex = 4;
            // 
            // rangeLabel
            // 
            this.rangeLabel.AutoSize = true;
            this.rangeLabel.Location = new System.Drawing.Point(13, 60);
            this.rangeLabel.Name = "rangeLabel";
            this.rangeLabel.Size = new System.Drawing.Size(114, 17);
            this.rangeLabel.TabIndex = 3;
            this.rangeLabel.Text = "Daily cost range:";
            // 
            // showAllButton
            // 
            this.showAllButton.Location = new System.Drawing.Point(587, 12);
            this.showAllButton.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.showAllButton.Name = "showAllButton";
            this.showAllButton.Size = new System.Drawing.Size(83, 26);
            this.showAllButton.TabIndex = 2;
            this.showAllButton.Text = "Show all";
            this.showAllButton.UseVisualStyleBackColor = true;
            this.showAllButton.Click += new System.EventHandler(this.showAllButton_Click);
            // 
            // searchButton
            // 
            this.searchButton.Enabled = false;
            this.searchButton.Location = new System.Drawing.Point(487, 12);
            this.searchButton.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.searchButton.Name = "searchButton";
            this.searchButton.Size = new System.Drawing.Size(93, 26);
            this.searchButton.TabIndex = 1;
            this.searchButton.Text = "Search";
            this.searchButton.UseVisualStyleBackColor = true;
            this.searchButton.Click += new System.EventHandler(this.searchButton_Click);
            // 
            // searchBox
            // 
            this.searchBox.ForeColor = System.Drawing.SystemColors.GrayText;
            this.searchBox.Location = new System.Drawing.Point(16, 13);
            this.searchBox.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.searchBox.Name = "searchBox";
            this.searchBox.Size = new System.Drawing.Size(413, 22);
            this.searchBox.TabIndex = 0;
            this.searchBox.Text = "Enter search query..";
            this.searchBox.Enter += new System.EventHandler(this.searchInitiate);
            this.searchBox.Leave += new System.EventHandler(this.searchLeave);
            // 
            // searchDataGridView
            // 
            this.searchDataGridView.AllowUserToAddRows = false;
            this.searchDataGridView.AllowUserToDeleteRows = false;
            this.searchDataGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.searchDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.searchDataGridView.Location = new System.Drawing.Point(0, 88);
            this.searchDataGridView.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.searchDataGridView.MultiSelect = false;
            this.searchDataGridView.Name = "searchDataGridView";
            this.searchDataGridView.ReadOnly = true;
            this.searchDataGridView.RowTemplate.Height = 24;
            this.searchDataGridView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.searchDataGridView.Size = new System.Drawing.Size(1192, 463);
            this.searchDataGridView.TabIndex = 9;
            this.searchDataGridView.Visible = false;
            // 
            // titleLable
            // 
            this.titleLable.AutoSize = true;
            this.titleLable.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.titleLable.Location = new System.Drawing.Point(27, 6);
            this.titleLable.Name = "titleLable";
            this.titleLable.Size = new System.Drawing.Size(372, 29);
            this.titleLable.TabIndex = 1;
            this.titleLable.Text = "MATES RATES RENT A CAR";
            // 
            // managementLabel
            // 
            this.managementLabel.AutoSize = true;
            this.managementLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.managementLabel.Location = new System.Drawing.Point(28, 36);
            this.managementLabel.Name = "managementLabel";
            this.managementLabel.Size = new System.Drawing.Size(154, 20);
            this.managementLabel.TabIndex = 2;
            this.managementLabel.Text = "Management Portal";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1200, 802);
            this.Controls.Add(this.managementLabel);
            this.Controls.Add(this.titleLable);
            this.Controls.Add(this.tabControl);
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "Form1";
            this.Text = "MRRC";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.ExitMMRC);
            this.tabControl.ResumeLayout(false);
            this.fleetPage.ResumeLayout(false);
            this.modifyVehicleGroupBox.ResumeLayout(false);
            this.modifyVehicleGroupBox.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownDailyRate)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownSeats)).EndInit();
            this.fleetGroupBox.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.fleetDataGridView)).EndInit();
            this.customersPage.ResumeLayout(false);
            this.modifyCustomerGroupBox.ResumeLayout(false);
            this.modifyCustomerGroupBox.PerformLayout();
            this.modifyCRMgroupBox.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.customersDataGridView)).EndInit();
            this.rentalReportPage.ResumeLayout(false);
            this.modifyRentalGroupBox.ResumeLayout(false);
            this.modifyRentalGroupBox.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.reportDataGridView)).EndInit();
            this.rentalSearchPage.ResumeLayout(false);
            this.rentalSearchPage.PerformLayout();
            this.createRentalGroupBox.ResumeLayout(false);
            this.createRentalGroupBox.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.searchDataGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl;
        private System.Windows.Forms.TabPage fleetPage;
        private System.Windows.Forms.TabPage customersPage;
        private System.Windows.Forms.TabPage rentalReportPage;
        private System.Windows.Forms.TabPage rentalSearchPage;
        private System.Windows.Forms.Label titleLable;
        private System.Windows.Forms.Label managementLabel;
        private System.Windows.Forms.GroupBox fleetGroupBox;
        private System.Windows.Forms.Button addFleet;
        private System.Windows.Forms.Button removeFleet;
        private System.Windows.Forms.Button modifyFleet;
        private System.Windows.Forms.GroupBox modifyCRMgroupBox;
        private System.Windows.Forms.Button addCustomer;
        private System.Windows.Forms.Button removeCustomer;
        private System.Windows.Forms.Button modifyCustomer;
        private System.Windows.Forms.GroupBox modifyRentalGroupBox;
        private System.Windows.Forms.Label totalDailyRentalChargeLabel;
        private System.Windows.Forms.Label dailychargelabel;
        private System.Windows.Forms.Label totalVehiclesRentedLabel;
        private System.Windows.Forms.Label rentedcarlabel;
        private System.Windows.Forms.Button returnVechicleButton;
        private System.Windows.Forms.GroupBox createRentalGroupBox;
        private System.Windows.Forms.NumericUpDown numericUpDown3;
        private System.Windows.Forms.ComboBox customerCreateRental;
        private System.Windows.Forms.Label rentalDurationLabel1;
        private System.Windows.Forms.Label customerLabel1;
        private System.Windows.Forms.Label tolabel;
        private System.Windows.Forms.NumericUpDown numericUpDown2;
        private System.Windows.Forms.NumericUpDown numericUpDown1;
        private System.Windows.Forms.Label rangeLabel;
        private System.Windows.Forms.Button showAllButton;
        private System.Windows.Forms.Button searchButton;
        private System.Windows.Forms.TextBox searchBox;
        private System.Windows.Forms.Button rentSearch;
        private System.Windows.Forms.Label totalCost;
        private System.Windows.Forms.Label totalcostLabel1;
        private System.Windows.Forms.DataGridView customersDataGridView;
        private System.Windows.Forms.DataGridView reportDataGridView;
        private System.Windows.Forms.DataGridView searchDataGridView;
        private System.Windows.Forms.GroupBox modifyVehicleGroupBox;
        private System.Windows.Forms.CheckBox checkBoxGPS;
        private System.Windows.Forms.CheckBox checkBoxSunRoof;
        private System.Windows.Forms.TextBox txtColour;
        private System.Windows.Forms.TextBox txtYear;
        private System.Windows.Forms.ComboBox txtTransmission;
        private System.Windows.Forms.ComboBox txtFuel;
        private System.Windows.Forms.ComboBox txtClass;
        private System.Windows.Forms.TextBox txtModel;
        private System.Windows.Forms.TextBox txtMake;
        private System.Windows.Forms.TextBox txtRego;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Button closeButton;
        private System.Windows.Forms.Button submitFleetButton;
        private System.Windows.Forms.DataGridView fleetDataGridView;
        private System.Windows.Forms.GroupBox modifyCustomerGroupBox;
        private System.Windows.Forms.Button submitCustomerButton;
        private System.Windows.Forms.Button closeButton2;
        private System.Windows.Forms.ComboBox txtGender;
        private System.Windows.Forms.TextBox txtLastName;
        private System.Windows.Forms.TextBox txtFirstName;
        private System.Windows.Forms.TextBox txtCustID;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.TextBox txtDOB;
        private System.Windows.Forms.NumericUpDown numericUpDownDailyRate;
        private System.Windows.Forms.NumericUpDown numericUpDownSeats;
        private System.Windows.Forms.Label txtTitleLabel;
        private System.Windows.Forms.TextBox txtTitle;
    }
}

