﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CardDealer
{
    class Deck
    {
        static string[] suit = { "Hearts", "Diamonds", "Clubs", "Spades" };

        static string[] card = { "Ace", "Two", "Three", "Four", "Five", "Six", "Seven",
                                "Eight", "Nine", "Ten", "Jack", "Queen", "King" };

        // Suit length
        static int SUITS = suit.Length;
        // Total cards (13 * 4 = 52)
        static int CARDS = card.Length;

        static int N = SUITS * CARDS;

        static string[] deck = new string[N];

        static int currentCard = 0;

        public Deck()
        {
            int deckCount = 0;
            for (int j = 0; j < SUITS; j++)
                for (int i = 0; i < CARDS; i++)
                    deck[deckCount++] = card[i] + " of " + suit[j];
        }

        public void Shuffle()
        {
            currentCard = 0;
            Random random = new Random();
            int r = 0;
            for (int i = N - 1; i > 0; i--)
            {
                int j = r = random.Next(0, (N - i));
                string temp = deck[i];
                deck[i] = deck[j];
                deck[j] = temp;
            }
        }

        public string Deal()
        {
            if (currentCard == 52)
                return "(all cards dealt)";
            return deck[currentCard++];

        }
    }
}


