﻿using System;

namespace RandomArray
{
    public class RandomArrayNoDuplicates
    {
        static Random rng = new Random();
        /// <summary>
        /// Creates an array with each element a unique integer
        /// between 1 and 45 inclusively.
        /// </summary>
        /// <param name="size"> length of the returned array < 45
        /// </param>
        /// <returns>an array of length "size" and each element is
        /// a unique integer between 1 and 45 inclusive </returns>
        public static int[] InitializeArrayWithNoDuplicates(int size)
        {
            bool[] repeated = new bool[45];
            int numRandom;
            int[] array = new int[size];
            for (int i = 0; i < size; i++)
            {
                while (true)
                {
                    numRandom = rng.Next(1, 46);
                    if (!repeated[numRandom - 1])
                    {
                        repeated[numRandom - 1] = true;
                        array[i] = numRandom;
                        break;
                    }
                }
            }
            return array;
        }
    }
}