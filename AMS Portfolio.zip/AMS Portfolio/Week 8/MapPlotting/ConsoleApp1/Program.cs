﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MapPlotting
{
    class Program
    {
        public static int getX()
        {
            int x = 0;
            int flag = 1;
            while (flag == 1)
            {
                Console.Write("Place a marker at which X coordinate? (0-70): ");
                string input = Console.ReadLine();
                bool isNumeric = int.TryParse(input, out x);
                if (isNumeric)
                {
                    if (x < 0 || x > 70)
                    {
                        Console.WriteLine("Out of range.");
                    }
                  
                    else
                    {
                        flag = 0;
                    }
                }
                else
                {
                    Console.WriteLine("Invalid input.");
                }
            }
            return x;
        }
        public static int getY()
        {
            int y = 0, flag = 1;
            while (flag == 1)
            {
                Console.Write("Place a marker at which Y coordinate? (0-11): ");
                string input = Console.ReadLine();
                bool isNumeric = int.TryParse(input, out y);
                if (isNumeric)
                {
                    if (y < 0 || y > 11)
                    {
                        Console.WriteLine("Out of range.");
                    }
                    else
                    {
                        flag = 0;
                    }
                }
           
                else
                {
                    Console.WriteLine("Invalid input.");
                }
            }
            return y;
        }
        public static void Main()
        {
            bool[,] map = new bool[12, 71];
            string choice = "y";
            while (choice == "y")
            {
                int x = 0, y = 0;
                x = getX();
                y = getY();
                map[y, x] = true;
                int flag = 0;
                while (true)
                {
                    Console.Write("More? (y/n): ");
                    string more = Console.ReadLine();
                    if (more == "y")
                    {
                        flag = 1;
                        break;
                    }
                    else if (more == "n")
                    {
                        choice = "n";
                        break;
                    }
                    else
                        Console.WriteLine("Please answer with y or n.");
                }
                if (flag == 0)
                {
                    for (int j = 0; j < 12; j++)
                    {
                        for (int i = 0; i < 71; i++)
                        {
                            if (map[j, i] == true)
                            {
                                Console.Write("X");
                            }
                           
                            else
                            {
                                Console.Write(".");
                            }
                        }
                        Console.WriteLine();
                    }
                    Console.WriteLine("Press enter to exit.");
                    Console.ReadLine();
                }
            }
        }
    }
}