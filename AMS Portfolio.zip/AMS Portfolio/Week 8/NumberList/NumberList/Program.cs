﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Numbers
{
    public class NumberList
    {
        // Your private List<float> field should go here
        private List<float> inputList = new List<float>();

        public void Add(float number)
        {
            inputList.Add(number);
        }

        public List<float> Numbers()
        {
            return inputList;
        }

        public float Minimum()
        {
            float min = inputList.Min();
            return min;
        }
        public float Maximum()
        {
            float max = inputList.Max();
            return max;
        }
        public float Sum()
        {
            float total = inputList.Sum();
            return total;
        }
        public float Average()
        {
            float total = inputList.Sum() / inputList.Count;
            return total;
        }
        public int Count()
        {
            return inputList.Count;
        }
        public void DeleteBelow(float threshold)
        {
            inputList.RemoveAll(x => x < threshold);
        }
        public void DeleteAbove(float threshold)
        {
            inputList.RemoveAll(x => x > threshold);
        }
        public int CountBelow(float threshold)
        {
            int count = 0;
            for (int i = 0; i < inputList.Count; i++)
            {
                if (inputList[i] < threshold)
                {
                    count = count + 1;
                }
            }
            return count;
        }
        public int CountAbove(float threshold)
        {
            int count = 0;
            for (int i = 0; i < inputList.Count; i++)
            {
                if (inputList[i] > threshold)
                {
                    count = count + 1;
                }
            }
            return count;
        }
    }
    public class Program
    {
        private static string ListToString(List<float> numbers)
        {
            string text = "";
            for (int i = 0; i < numbers.Count; i++)
            {
                if (i > 0) text += ", ";
                text += String.Format("{0}", numbers[i]);
            }
            text += "";
            return text;
        }
        static void Main(string[] args)
        {
            NumberList myList = new NumberList();
            myList.Add(1);
            myList.Add(2);
            myList.Add(3);
            myList.Add(4);
            myList.Add(5);

            Console.WriteLine("{0} should be 1", myList.Minimum());
            Console.WriteLine("{0} should be 5", myList.Maximum());
            Console.WriteLine("{0} should be 15", myList.Sum());
            Console.WriteLine("{0} should be 3", myList.Average());
            Console.WriteLine("{0} should be 5", myList.Count());
            Console.WriteLine("{0} should be 2", myList.CountBelow(2.5f));
            Console.WriteLine("{0} should be 2", myList.CountAbove(3.5f));

            Console.WriteLine("{0} should be 1, 2, 3, 4, 5", ListToString(myList.Numbers()));
            myList.DeleteBelow(2.5f);
            Console.WriteLine("{0} should be 3, 4, 5", ListToString(myList.Numbers()));

            myList.Add(6);
            myList.Add(7);

            myList.DeleteAbove(4.5f);
            Console.WriteLine("{0} should be 3, 4", ListToString(myList.Numbers()));

            Console.WriteLine("\nPress enter to exit.");
            Console.ReadLine();
        }
    }
}