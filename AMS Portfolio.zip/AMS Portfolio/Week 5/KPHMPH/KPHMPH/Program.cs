﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
namespace SpeedConversion
{
    class MilesPerHourTable
    {
        public static void Main()
        {
            // Write your code to create the KPH to MPH table here
            double mph;

            Console.WriteLine("KPH\tMPH"); // Column headings
            for (double kph = 45; kph <= 180; kph+= 15)
            {
                mph = kph / 1.60934;
                Console.WriteLine("{0}\t{1:N}", kph, mph);
            }

            Console.WriteLine("\n\n Hit Enter to exit.");
            Console.ReadLine();
        }
    }
}