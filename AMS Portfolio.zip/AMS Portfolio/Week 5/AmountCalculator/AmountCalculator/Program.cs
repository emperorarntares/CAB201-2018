﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PurchaseApp
{
    class PurchaseCalc
    {
        public static void Main()
        {
            string input; //user input number
            double inputSum, purchase = 0; // total purchases
            double salesTax; // sales tax
            double shippingCharge = 0;
            double grandTotal;
            int noItems = 0; // no. items purchased


            Console.WriteLine("This application computes the total due for your purchases.");
            Console.WriteLine("It will allow you to enter any number of purchase amounts, and then display a receipt.");

            Console.Write("\n\nPress enter when you are ready to begin...");
            Console.ReadLine();


            Console.Write("\nWhat is the amount of the item? - ");
            input = Console.ReadLine();

            bool inputInitial = double.TryParse(input, out inputSum) && (inputSum >= 0);

            if (inputInitial == true)
            {
                purchase += inputSum;
                noItems++;
            }

            // when input is not a number or is negative
            while (!double.TryParse(input, out inputSum) || inputSum < 0)
            {
                Console.Write("Invalid data - Please re-enter the amount of the item - ");
                input = Console.ReadLine();

                bool inputFix = double.TryParse(input, out inputSum) && (inputSum >= 0);

                if (inputFix == true)
                {
                    purchase += inputSum;
                    noItems++;
                }
            }

            // input either y or n 
            do
            {
                Console.Write("\nDo you want to enter more purchases? - Y or N ");
                input = Console.ReadLine();
                var yes = input?.ToLower();
                var no = input?.ToLower();

                // call y to add more items
                if (yes == "y")
                {

                    Console.Write("\nWhat is the amount of the item? - ");
                    input = Console.ReadLine();

                    bool inputAdd = double.TryParse(input, out inputSum) && (inputSum >= 0);

                    if (inputAdd == true)
                    {
                        purchase += inputSum;
                        noItems++;
                    }

                    while (!double.TryParse(input, out inputSum) || inputSum < 0)
                    {
                        Console.Write("Invalid data - Please re-enter the amount of the item - ");
                        input = Console.ReadLine();

                        bool inputFix2 = double.TryParse(input, out inputSum) && (inputSum >= 0);

                        if (inputFix2 == true)
                        {
                            purchase += inputSum;
                            noItems++;
                        }
                    }
                }

                // call n to get receipt
                if (no == "n")
                {
                    // calculate sales tax, shipping charge & grand total
                    salesTax = purchase * 0.1;

                    if (noItems < 3)
                    {
                        shippingCharge = 3.5;
                    }

                    else if (noItems >= 3 && noItems <= 6)
                    {
                        shippingCharge = 5;
                    }

                    else if (noItems >= 7 && noItems <= 10)
                    {
                        shippingCharge = 7;
                    }

                    else if (noItems >= 11 && noItems <= 15)
                    {
                        shippingCharge = 9;
                    }

                    else
                    {
                        shippingCharge = 10;
                    }

                    grandTotal = purchase + salesTax + shippingCharge;

                    // add receipt code here
                    Console.WriteLine("-----------------------------------------");
                    Console.WriteLine("              Sales Receipt              ");
                    Console.WriteLine("-----------------------------------------");
                    Console.WriteLine("Total Purchases:\t\t\t${0:N}", purchase);
                    Console.WriteLine("Sales Tax:\t\t\t\t${0:N}", salesTax);
                    Console.WriteLine("Number of Items Purchased:\t\t{0}", noItems);
                    Console.WriteLine("Shipping charge:\t\t\t${0:N}", shippingCharge);
                    Console.WriteLine("-----------------------------------------");
                    Console.WriteLine("Grand Total:\t\t\t\t${0:N}", grandTotal);
                    break;
                }
            } while (true);


            Console.WriteLine("\n\n Hit Enter to exit.");
            Console.ReadLine();
        }
    }
}