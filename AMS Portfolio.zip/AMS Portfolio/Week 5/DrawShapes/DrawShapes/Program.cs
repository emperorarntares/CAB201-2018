﻿using System;

namespace Shapes
{
    public class ShapeDrawer
    {

        public static string DrawSquare(int height, int width)
        {
            // Write your code to draw the square here
            string square = "";
            string error = "Cannot draw that shape.";

            if (height < 1 || width < 1)
            {
                return error;
            }

            else
            {
                for (int i = 1; i <= height; i++)
                {
                    for (int j = 1; j <= width; j++)
                    {
                        if (i == 1 | j == 1 || i == height || j == width)
                        {
                            square = square + "-";
                        }
                        else
                        {
                            square = square + " ";
                        }
                    }
                    square = square + "\n";
                }
            }
            return square;
        }

        public static string DrawIsoscelesTriangle(int size)
        {
            // Write your code to draw the triangle here
            string triangle = "";
            string error = "Cannot draw that shape.";

            if (size < 2)
            {
                return error;
            }

            else
            {
                for (int i = 1; i <= size; i++)
                {
                    for (int j = 1; j <= i; j++)
                    {
                        triangle = triangle + "$";
                    }
                    triangle = triangle + "\n";
                }
                for (int i = size - 1; i >= 1; i--)
                {
                    for (int j = 1; j <= i; j++)
                    {
                        triangle = triangle + "$";
                    }
                    triangle = triangle + "\n";
                }
            }

            return triangle;
        }
    }
}