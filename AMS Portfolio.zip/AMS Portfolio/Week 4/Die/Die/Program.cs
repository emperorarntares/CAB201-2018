﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DieRoller
{
    /// <summary>
    /// Represents one die (singular of dice) with faces showing values between
    /// 1 and the number of faces on the die.
    /// </summary>
    public class Die
    {
        // Implement your 'Die' class here
        private int numFaces;
        private int faceValue;
        Random r = new Random();

        public Die()
        {
            numFaces = 6;
            faceValue = 1;
        }

        public Die(int faces)
        {
            numFaces = faces;
            if (faces < 3)
            {
                numFaces = 6;
            }
            faceValue = 1;
        }

        public void RollDie()
        {
            faceValue = r.Next(1, numFaces +1);
        }

        public int GetFaceValue()
        {
            return faceValue;
        }

        public int GetNumFaces()
        {
            return numFaces;
        }

    }// end Class Die

    public class Program
    {
        public static void Main()
        {
            // This will not be called by the AMS, however you may want to test your Die class here.
            Die myDie = new Die(6);
            Console.WriteLine(myDie.GetFaceValue());
            Console.WriteLine(myDie.GetNumFaces());
            Console.ReadKey();
        }
    }
}
