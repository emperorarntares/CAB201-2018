﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RangeRestrictedInteger
{
    public class RangedInteger
    {
        // Add private variables here, as necessary
        private int val, minimum, maximum;

        public RangedInteger(int min, int max)
        {
            minimum = min;
            maximum = max;
        }

        public int Value
        {
            get
            {
                return val;
            }
            set
            {
                if (value <= minimum)
                {
                    val = minimum;
                }

                else if (value > minimum && value < maximum)
                {
                    val = value;
                }

                else
                {
                    val = maximum;
                }
            }
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            RangedInteger myInteger = new RangedInteger(0, 100);
            myInteger.Value = 57;
            Console.WriteLine("{0}", myInteger.Value); // Should be 57
            myInteger.Value = 103;
            Console.WriteLine("{0}", myInteger.Value); // Should be 100
            myInteger.Value = -4;
            Console.WriteLine("{0}", myInteger.Value); // Should be 0

            Console.WriteLine("\nPress enter to exit.");
            Console.ReadLine();
        }
    }
}
