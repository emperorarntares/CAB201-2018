﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MilesToKm
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void milesToKilometresRadio_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void kilometersToMilesRadio_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void inputText_TextChanged(object sender, EventArgs e)
        {

        }

        private void buttonConvert_Click(object sender, EventArgs e)
        {
            double distance, convertedDistance;
            if(double.TryParse(inputText.Text, out distance))
            {
                if(milesToKilometresRadio.Checked)
                {
                    convertedDistance = distance * 1.60934;
                    result.Text = "Distance in kilometres is " + convertedDistance.ToString("00.00");
                }

                if (kilometersToMilesRadio.Checked)
                {
                    convertedDistance = distance * 0.621371;
                    result.Text = "Distance in miles is " + convertedDistance.ToString("00.00");
                }
            }

            else
            {
                result.Text = "Invalid input";
            }
        }

        private void result_Click(object sender, EventArgs e)
        {
            
        }
    }
}
