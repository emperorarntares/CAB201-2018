﻿namespace MilesToKm
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.milesToKilometresRadio = new System.Windows.Forms.RadioButton();
            this.kilometersToMilesRadio = new System.Windows.Forms.RadioButton();
            this.inputLabel = new System.Windows.Forms.Label();
            this.inputText = new System.Windows.Forms.TextBox();
            this.buttonConvert = new System.Windows.Forms.Button();
            this.result = new System.Windows.Forms.Label();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.SuspendLayout();
            // 
            // milesToKilometresRadio
            // 
            this.milesToKilometresRadio.AutoSize = true;
            this.milesToKilometresRadio.Font = new System.Drawing.Font("Tahoma", 16.125F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.milesToKilometresRadio.Location = new System.Drawing.Point(124, 37);
            this.milesToKilometresRadio.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.milesToKilometresRadio.Name = "milesToKilometresRadio";
            this.milesToKilometresRadio.Size = new System.Drawing.Size(214, 31);
            this.milesToKilometresRadio.TabIndex = 0;
            this.milesToKilometresRadio.TabStop = true;
            this.milesToKilometresRadio.Text = "Miles to Kilometres\r\n";
            this.milesToKilometresRadio.UseVisualStyleBackColor = true;
            this.milesToKilometresRadio.CheckedChanged += new System.EventHandler(this.milesToKilometresRadio_CheckedChanged);
            // 
            // kilometersToMilesRadio
            // 
            this.kilometersToMilesRadio.AutoSize = true;
            this.kilometersToMilesRadio.Font = new System.Drawing.Font("Trebuchet MS", 16.125F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.kilometersToMilesRadio.Location = new System.Drawing.Point(124, 83);
            this.kilometersToMilesRadio.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.kilometersToMilesRadio.Name = "kilometersToMilesRadio";
            this.kilometersToMilesRadio.Size = new System.Drawing.Size(225, 31);
            this.kilometersToMilesRadio.TabIndex = 1;
            this.kilometersToMilesRadio.TabStop = true;
            this.kilometersToMilesRadio.Text = "Kilometres to Miles\r\n";
            this.kilometersToMilesRadio.UseVisualStyleBackColor = true;
            this.kilometersToMilesRadio.CheckedChanged += new System.EventHandler(this.kilometersToMilesRadio_CheckedChanged);
            // 
            // inputLabel
            // 
            this.inputLabel.AutoSize = true;
            this.inputLabel.Font = new System.Drawing.Font("Courier New", 19.875F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.inputLabel.Location = new System.Drawing.Point(22, 142);
            this.inputLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.inputLabel.Name = "inputLabel";
            this.inputLabel.Size = new System.Drawing.Size(254, 31);
            this.inputLabel.TabIndex = 2;
            this.inputLabel.Text = "Enter distance:\r\n";
            // 
            // inputText
            // 
            this.inputText.Font = new System.Drawing.Font("Trebuchet MS", 16.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.inputText.Location = new System.Drawing.Point(302, 142);
            this.inputText.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.inputText.Name = "inputText";
            this.inputText.Size = new System.Drawing.Size(128, 32);
            this.inputText.TabIndex = 3;
            this.inputText.TextChanged += new System.EventHandler(this.inputText_TextChanged);
            // 
            // buttonConvert
            // 
            this.buttonConvert.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonConvert.Location = new System.Drawing.Point(183, 210);
            this.buttonConvert.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.buttonConvert.Name = "buttonConvert";
            this.buttonConvert.Size = new System.Drawing.Size(92, 34);
            this.buttonConvert.TabIndex = 4;
            this.buttonConvert.Text = "Convert\r\n";
            this.buttonConvert.UseVisualStyleBackColor = true;
            this.buttonConvert.Click += new System.EventHandler(this.buttonConvert_Click);
            // 
            // result
            // 
            this.result.AutoSize = true;
            this.result.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.result.Location = new System.Drawing.Point(113, 279);
            this.result.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.result.Name = "result";
            this.result.Size = new System.Drawing.Size(238, 18);
            this.result.TabIndex = 5;
            this.result.Text = "Distance in kilometres is __";
            this.result.Click += new System.EventHandler(this.result_Click);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(61, 4);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(457, 342);
            this.Controls.Add(this.result);
            this.Controls.Add(this.buttonConvert);
            this.Controls.Add(this.inputText);
            this.Controls.Add(this.inputLabel);
            this.Controls.Add(this.kilometersToMilesRadio);
            this.Controls.Add(this.milesToKilometresRadio);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "Form1";
            this.Text = "Miles and Kilometres Converter";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RadioButton milesToKilometresRadio;
        private System.Windows.Forms.RadioButton kilometersToMilesRadio;
        private System.Windows.Forms.Label inputLabel;
        private System.Windows.Forms.TextBox inputText;
        private System.Windows.Forms.Button buttonConvert;
        private System.Windows.Forms.Label result;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
    }
}

