﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookFinder
{
    /// <summary>
    /// Simple representation of a book with its title and topics.
    /// - Do not change this code - 
    /// </summary>
    public class Book
    {
        public string Title { get; set; }
        private List<string> topics;

        /// <summary>
        /// Constructs a book object with the provided title and topics.
        /// </summary>
        /// <param name="title">String representing the title of the book.</param>
        /// <param name="topics">List of significant topics in the book</param>
        public Book(string title, List<string> topics)
        {
            Title = title;
            this.topics = topics;
        }

        /// <summary>
        /// Returns whether the book contains the provided topic.
        /// </summary>
        /// <param name="topic">Topic to check for</param>
        /// <returns>True if the book contains the topic, false otherwise</returns>
        public bool ContainsTopic(string topic)
        {
            return topics.Contains(topic);
        }
    }


    public class BookCollection
    {
        private List<Book> books;

        /// Implement your BookCollection class here
 
        //This constructor creates an empty BookCollection. 
        public BookCollection()
        {
            books = new List<Book>();
        }

        //This constructor creates a collection of books with the provided list of books included.
        //The class must also have several other methods which allow for adding books and finding books with topics:  
        public BookCollection(List<Book> books)
        {
            this.books = books;
        }

        //This method should add a book to the collection. Note - usually this method would check whether the book was already in the collection, however this method has been simplified 
        //for this exercise. 
        public void AddBook(Book book)
        {
            books.Add(book);
        }

        //This method should return the collection of books. 
        public List<Book> GetBooks()
        {
            return books;
        }
        //This method should find books which contain the topic topic. It should return a list of the titles of the books which contain the topic. It is recommended that you implement this 
        //method before the following two. 
        public List<string> BooksWithTopic(string topic)
        {
            List<string> topics = new List<string>();
            foreach (Book b in books)
            {
                if (b.ContainsTopic(topic))
                {
                    topics.Add(b.Title);
                }
            }
            return topics;
        }
        //This method should find books which contain any of the topics in the list topics. For example, if the list of topics is ["fantasy", "science"] it should return any book with 
        //the topic fantasy OR science. It should return a list of the titles of the books which contain any of the topics. You may want to make use of the BooksWithTopic method here.
        public List<string> BooksWithAnyTopic(string[] topics)
        {
            List<string> titles = new List<string>();

            foreach (Book b in books)
            {
                if (b.ContainsTopic(topics[0]) || b.ContainsTopic(topics[1]))
                {
                    titles.Add(b.Title);
                }
            }
            return titles;


        }
        //This method should find books which contain all of the topics in the list topics. For example, if the list of topics is ["fantasy", "science"] it should return any book with 
        //the topic fantasy AND science. It should return a list of the titles of the books which contain all of the topics. You may want to make use of the BooksWithTopic method here. 
        public List<string> BooksWithAllTopics(string[] topics)
        {
            List<string> titles = new List<string>();
            foreach (Book b in books)
            {
                if (b.ContainsTopic(topics[0]) && b.ContainsTopic(topics[1]))
                {
                    titles.Add(b.Title);
                }
            }
            return titles;
        }
    }

    /// <summary>
    /// Simple tester for the program.
    /// </summary>
    class Program
    {
        static void Main(string[] args)
        {
            // Create list of books for the collection
            List<Book> books = new List<Book>() {
            new Book("Game of Thrones", new List<string>() { "fantasy", "dragons", "drama",
            "fiction", "king", "queen", "medieval", "epic"}),
            new Book("The Fellowship of the Ring", new List<string>() {"fantasy", "fiction",
            "epic", "wizard", "elves"}),
            new Book("Small Gods", new List<string>() {"fantasy", "fiction", "religion",
            "philosophy", "satire"}),
            new Book("The Gene: An Intimate History", new List<string>() {"non-fiction",
            "science", "genetics", "medicine" }),
            new Book("Sapiens: A brief History of Humankind", new List<string>() {"non-fiction",
            "anthropology", "evolution", "history"}),
            new Book("The Martian", new List<string>() {"fiction", "science", "science fiction",
            "space" })
            };
            BookCollection library = new BookCollection(books);

            // Some simple test cases are included here - you may want to test more.
            // The AMS will not use the same test cases.
            // Check for single topic:
            string topic = "fantasy";
            List<string> results = library.BooksWithTopic(topic);
            // Display results
            Console.WriteLine("Book with topic 'fantasy'.");
            display(results);
            // Check for any of several topics
            string[] topics = new string[] { "fantasy", "religion" };
            results = library.BooksWithAnyTopic(topics);
            // Display results
            Console.WriteLine("Book with topic 'fantasy or religion'.");
            display(results);
            // Check for all of several topics
            results = library.BooksWithAllTopics(topics);
            // Display results
            Console.WriteLine("Book with topic 'fantasy AND religion'.");
            display(results);

            // Exit
            Console.WriteLine("\n\nPress enter to exit.");
            Console.ReadLine();
        }

        // You might want to write some simple helper methods for displaying lists here
        // (Remember DRY [Don't Repeat Yourself]- if you're writing the same chunk of code
        // over and over, it should probably be a method!)
        public static void display(List<string> results)
        {
            Console.WriteLine("--------------------------------------");
            foreach (String s in results)
            {
                Console.WriteLine(s);
            }
            Console.WriteLine("--------------------------------------");
        }

    }
}

