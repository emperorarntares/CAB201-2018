﻿using System;

namespace RomanNumerals
{
    class RomanNumeralConverter
    {
        public static void Main()
        {
            int number;
            string roman;

            Console.Write("Enter a number between 1 and 10: ");
            string input = Console.ReadLine();

            while (!int.TryParse(input, out number) || number < 1 || number > 10)
            {
                if (number < 1 || number > 10)
                {
                    Console.WriteLine("Your number must be between 1 and 10.");
                }

                else
                {
                    Console.WriteLine("Your input must be a number.");
                }

                Console.Write("Enter a number between 1 and 10: ");
                input = Console.ReadLine();
            }

            if (number <= 3)
            {
                roman = new string('I', number);
                Console.WriteLine(input + " when written in Roman numerals is " + roman);
            }

            if (number == 4)
            {
                Console.WriteLine(input + " when written in Roman numerals is IV");
            }

            if (number >= 5 && number < 9)
            {
                roman = new String('I', number - 5);
                Console.WriteLine(input + " when written in Roman numerals is V" + roman);
            }

            if (number == 9)
            {
                Console.WriteLine(input + " when written in Roman numerals is IX");
            }

            if (number == 10)
            {
                Console.WriteLine(input + " when written in Roman numerals is X");
            }


            Console.WriteLine("Press enter to exit.");
            Console.ReadLine();
        }
        
    }
}
