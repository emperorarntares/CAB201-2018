﻿using System;

public class FirstProgram
{
    public static void Main()
    {
        Console.WriteLine("Hello World - Welcome to CAB201");
        Console.ReadLine();
    }
}
